<?php

class MY_ACF_DISINFECTANT extends ACF_CONSTRUCTOR {
  // use in acf_add_local_field_group() 
  public $acf_group_key = 'acfconst_' . 'disinfectant' . '_group_key';

  public $active_acf_1;
  public $active_acf_1_title = 'Настройка дезинф. средства';

  public $location;

  public $acf;

  public $excluded_fields;

  public $unique_id_prefix = 'disinfectant';

  /**
   * @param Array $args
   *    @param Array $args['location'] - where to print this ACF
   *    @param Array $args['exclude_fields'] - array of field names that you want to exclude
   */
  public function __construct( $args=[] ) {

    $this->location = [
      array(
        [
          'param' => 'page',
          'operator' => '==',
          'value' => get_option( '__disinfectant_post_id__' ),
        ],
      ),
    ];
  }


  public function register() {
    $this->acf = (object) [];
    $this->register_acf();
    add_action( 'acf/init', [$this, 'acf_init'] );
  }


  public function register_acf() {
    $this->active_acf_1 = [
      $this->acf_image([
        'id' => $this->id( 20 ),
        'name' => 'advantage_img',
        'label' => 'Знак опасности',
        'wrapper' => [ 'width' => 50 ],
        'preview_size' => 'medium',
      ]),
      
      $this->acf_group([
        'id' => $this->id( 100 ),
        'name' => 'card',
        'label' => 'Карточка товара',
        'sub_fields' => [
          $this->acf_text([
            'id' => $this->id( 100, 100 ),
            'name' => 'front_page_h1',
            'label' => 'Главный заголовок (на глав. странице)',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_text([
            'id' => $this->id( 100, 200 ),
            'name' => 'other_page_h1_1',
            'label' => 'Главный заголовок часть 1 (остальные страницы)',
            'wrapper' => [ 'width' => 50 ],
          ]),
          $this->acf_text([
            'id' => $this->id( 100, 300 ),
            'name' => 'other_page_h1_2',
            'label' => 'Главный заголовок часть 2 (остальные страницы)',
            'wrapper' => [ 'width' => 50 ],
          ]),
          $this->acf_image([
            'id' => $this->id( 100, 350 ),
            'name' => 'main_img',
            'label' => 'Изображ. товара',
            'wrapper' => [ 'width' => 50 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 100, 400 ),
            'name' => 'left_col_content',
            'label' => 'Контент в левой колонке',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 100, 500 ),
            'name' => 'top_description',
            'label' => 'Верхнее описание',
            'wrapper' => [ 'width' => 100 ],
          ]),
        ],
      ]),

      $this->acf_group([
        'id' => $this->id( 200 ),
        'name' => 'page',
        'label' => 'Контент страницы',
        'sub_fields' => [
          $this->acf_image([
            'id' => $this->id( 200, 100 ),
            'name' => 'main_img',
            'label' => 'Изображ. товара',
            'wrapper' => [ 'width' => 50 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_image([
            'id' => $this->id( 200, 200 ),
            'name' => 'quality_sign_img',
            'label' => 'Изображ. знака качества',
            'wrapper' => [ 'width' => 50 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 200, 300 ),
            'name' => 'h1',
            'label' => 'Заголовок (под основной картинкой)',
            'wrapper' => [ 'width' => 100 ],
            'rows' => 2,
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 200, 400 ),
            'name' => 'h_description',
            'label' => 'Верхнее описание',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 200, 500 ),
            'name' => 'left_col_content',
            'label' => 'Контент в левой колонке',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 200, 600 ),
            'name' => 'right_col_content',
            'label' => 'Контент в правой колонке',
            'wrapper' => [ 'width' => 100 ],
          ]),

        ],
      ]),
    ]; // $this->active_acf_1
  }


  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => $this->active_acf_1_title,
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
    };
  }
  
} // class ACF_CONSTRUCTOR_PRODUCTS