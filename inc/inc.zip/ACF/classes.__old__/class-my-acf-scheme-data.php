<?php

class MY_ACF_SCHEME_DATA extends ACF_CONSTRUCTOR {
  // use in acf_add_local_field_group() 
  public $acf_group_key = 'acfconst_' . 'scheme_data' . '_group_key';

  public $active_acf_1;
  public $active_acf_1_title = 'Настройка пункта';

  public $location;

  public $acf;

  public $excluded_fields;

  public $unique_id_prefix = 'scheme_data';

  /**
   * @param Array $args
   *    @param Array $args['location'] - where to print this ACF
   *    @param Array $args['exclude_fields'] - array of field names that you want to exclude
   */
  public function __construct( $args=[] ) {
    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => MY_CPT_SCHEME_DATA,
        ],
      ),
    ];
  }


  public function register() {
    $this->acf = (object) [];
    $this->register_acf();
    add_action( 'acf/init', [$this, 'acf_init'] );
  }


  public function register_acf() {
    $this->active_acf_1 = [
      $this->acf_image([
        'id' => $this->id( 'aa1', 100 ),
        'name' => 'img',
        'label' => 'Изобр.',
        'wrapper' => [ 'width' => 15 ],
        'preview_size' => 'medium',
      ]),
      $this->acf_textarea([
        'id' => $this->id( 'aa1', 200 ),
        'name' => 'title',
        'label' =>'Заголовок',
        'wrapper' => [ 'width' => 30 ],
        'rows' => 3,
      ]),
      $this->acf_wysiwyg_editor([
        'id' => $this->id( 'aa1', 300 ),
        'name' => 'description',
        'label' => 'Описание детали',
        'wrapper' => [ 'width' => 55 ],
      ]),
    ]; // $this->active_acf_1
  }


  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => $this->active_acf_1_title,
        'group_key' => $this->acf_group_key . '_aa1',
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
    };
  }
  
} // class MY_ACF_SCHEME_DATA