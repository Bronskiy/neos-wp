<?php

class MY_ACF_PRODUCTS extends ACF_CONSTRUCTOR {
  // use in acf_add_local_field_group() 
  public $acf_group_key = 'acfconst_' . 'products' . '_group_key';

  public $active_acf_1;
  public $active_acf_1_title = 'Настройка карточки продукта';

  public $active_acf_2;
  public $active_acf_2_title = 'Общая информация';

  public $active_acf_3;
  public $active_acf_3_title = 'Изображение с деталями';

  public $location;

  public $acf;

  public $excluded_fields;

  public $unique_id_prefix = 'products';

  /**
   * @param Array $args
   *    @param Array $args['location'] - where to print this ACF
   *    @param Array $args['exclude_fields'] - array of field names that you want to exclude
   */
  public function __construct( $args=[] ) {
    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => MY_CPT_PRODUCTS, // __product
        ],
      ),
    ];
  }


  public function register() {
    $this->acf = (object) [];
    $this->register_acf();
    add_action( 'acf/init', [$this, 'acf_init'] );
  }


  public function register_acf() {
    $this->active_acf_1 = [
      $this->acf_group([
        'id' => $this->id( 'aa1', 100 ),
        'name' => 'card',
        'label' => 'Карточка товара',
        'sub_fields' => [
          $this->acf_number([
            'id' => $this->id( 'aa1', 100, 100 ),
            'name' => 'post_order',
            'label' => 'Порядок карточки',
            'wrapper' => [ 'width' => 20 ],
          ]),
          $this->acf_image([
            'id' => $this->id( 'aa1', 100, 200 ),
            'name' => 'card_avatar',
            'label' => 'Аватар карточки',
            'wrapper' => [ 'width' => 40 ],
            'preview_size' => 'thumbnail',
          ]),
          $this->acf_text([
            'id' => $this->id( 'aa1', 100, 300 ),
            'name' => 'h2',
            'label' => 'Малый заголовок',
            'wrapper' => [ 'width' => 40 ],
          ]),
          $this->acf_text([
            'id' => $this->id( 'aa1', 100, 400 ),
            'name' => 'h1',
            'label' => 'Большой заголовок',
            'wrapper' => [ 'width' => 40 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 'aa1', 100, 500 ),
            'name' => 'top_description',
            'label' => 'Верхнее описание',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_image([
            'id' => $this->id( 'aa1', 100, 550 ),
            'name' => 'extra_img',
            'label' => 'Доп. изображение',
            'wrapper' => [ 'width' => 50 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 'aa1', 100, 600 ),
            'name' => 'bottom_description',
            'label' => 'Нижнее описание',
            'wrapper' => [ 'width' => 100 ],
          ]),
        ],
      ]),
    ]; // $this->active_acf_1



    $this->active_acf_2 = [
      $this->acf_group([
        'id' => $this->id( 'aa2', 100 ),
        'name' => 'product',
        'label' => 'Инф-ия о продукте',
        'sub_fields' => [
          $this->acf_image([
            'id' => $this->id( 'aa2', 100, 100 ),
            'name' => 'main_img',
            'label' => 'Главн. изображение',
            'wrapper' => [ 'width' => 100 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_text([
            'id' => $this->id( 'aa2', 100, 200 ),
            'name' => 'h2',
            'label' => 'Малый заголовок',
            'wrapper' => [ 'width' => 50 ],
          ]),
          $this->acf_text([
            'id' => $this->id( 'aa2', 100, 300 ),
            'name' => 'h1',
            'label' => 'Большой заголовок',
            'wrapper' => [ 'width' => 50 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 'aa2', 100, 400 ),
            'name' => 'h_description',
            'label' => 'Заголовок под главн. изображ.',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_wysiwyg_editor([
            'id' => $this->id( 'aa2', 100, 500 ),
            'name' => 'description',
            'label' => 'Текст под главной секицей',
            'wrapper' => [ 'width' => 100 ],
          ]),
          $this->acf_repeater([
            'id' => $this->id( 'aa2', 100, 600 ),
            'name' => 'base',
            'label' => 'База (список)',
            'button_label' => 'Добавить пункт',
            'wrapper' => [ 'width' => 50 ],
            'sub_fields' => [
              $this->acf_textarea([
                'id' => $this->id( 'aa2', 100, 600, 100 ),
                'name' => 'item',
                'label' =>'Пункт',
                'required' => true,
                'rows' => 2,
              ]),
            ],
          ]),
          $this->acf_repeater([
            'id' => $this->id( 'aa2', 100, 700 ),
            'name' => 'options',
            'label' => 'Опции (список)',
            'button_label' => 'Добавить пункт',
            'wrapper' => [ 'width' => 50 ],
            'sub_fields' => [
              $this->acf_textarea([
                'id' => $this->id( 'aa2', 100, 700, 100 ),
                'name' => 'item',
                'label' =>'Пункт',
                'required' => true,
                'rows' => 2,
              ]),
            ],
          ]),
          $this->acf_repeater([
            'id' => $this->id( 'aa2', 100, 800 ),
            'name' => 'specifications',
            'label' => 'Тех. характеристики (список)',
            'button_label' => 'Добавить пункт',
            'sub_fields' => [
              $this->acf_textarea([
                'id' => $this->id( 'aa2', 100, 800, 100 ),
                'name' => 'key',
                'label' =>'Название',
                'required' => true,
                'wrapper' => [ 'width' => 50 ],
                'rows' => 2,
              ]),
              $this->acf_textarea([
                'id' => $this->id( 'aa2', 100, 800, 200 ),
                'name' => 'value',
                'label' =>'Значение',
                'required' => true,
                'wrapper' => [ 'width' => 50 ],
                'rows' => 2,
              ]),
            ],
          ]),
        ], // sub_fields
      ]),
    ]; // $this->active_acf_2



    $this->active_acf_3 = [
      $this->acf_group([
        'id' => $this->id( 'aa3', 100 ),
        'name' => 'product_scheme',
        'label' => 'Схема продукта',
        'sub_fields' => [
          $this->acf_image([
            'id' => $this->id( 'aa3', 100, 100 ),
            'name' => 'scheme_img',
            'label' => 'Схема продукта',
            'wrapper' => [ 'width' => 100 ],
            'preview_size' => 'medium',
          ]),
          $this->acf_repeater([
            'id' => $this->id( 'aa3', 100, 200 ),
            'name' => 'scheme_items',
            'label' => 'Детали схемы',
            'button_label' => 'Добавить пункт',
            'layout' => 'block',
            'sub_fields' => [
              $this->acf_select([
                'id' => $this->id( 'aa3', 100, 200, 100 ),
                'name' => 'item_name',
                'label' =>'Тип детали',
                'required' => true,
                'choices' => isset($args['choices']) ? $args['choices'] : [
                  'motion_sensor' => 'Датчик движения',
                  'remote_control' => 'Пульт управления',
                  'touch_temperature_meter' => 'Сенсорный измеритель температуры',
                  'pass_system_by_cards' => 'Пропускная система по карточкам',
                  'turnstile' => 'Турникет',
                  'turnstile_pos_2' => 'Турникет (поз. 2)',
                  'steam_disinf_system' => 'Система дезинфекции паром',
                  'steam_disinf_system_pos_2' => 'Система дезинфекции паром (поз. 2)',
                  'steam_disinf_system_pos_3' => 'Система дезинфекции паром (поз. 3)',
                  'mask_dispenser' => 'Устройство выдачи масок',
                  'mask_dispenser_pos_2' => 'Устройство выдачи масок (поз. 2)',
                  'sensory_disinf_dispenser' => 'Сенсорный дозатор для дезинфицирующих средств',
                  'sensory_disinf_dispenser_pos_2' => 'Сенсорный дозатор для дезинфицирующих средств (поз. 2)',
                  'putting_shoe_covers_tool' => 'Аппарат для надевания бахил',
                  'metal_detector' => 'Металлодетектор',
                  'alcohol_breathalyzer' => 'Автоматический алкотестер',
                  'luggage_compartment_disinf_unit' => 'Блок обеззараживания для багажника',
                ],
                'wrapper' => [ 'width' => 40 ],
                'return_format' => 'array',
              ]),
              $this->acf_post_object([
                'id' => $this->id( 'aa3', 'prep_item_cond' ),
                'name' => 'prepared_item',
                'label' => 'Готовый данные детали',
                'wrapper' => [ 'width' => 40 ],
                'post_type' => [ 'scheme_data' ],
                'allow_null' => 1,
                'return_format' => 'id',
              ]),
              $this->acf_textarea([
                'id' => $this->id( 'aa3', 100, 200, 200 ),
                'name' => 'title',
                'label' =>'Заголовок',
                'wrapper' => [ 'width' => 20 ],
                'rows' => 3,
                'conditional_logic' => [
                  array([
                    'field' => $this->id( 'aa3', 'prep_item_cond' ),
                    'operator' => '==empty',
                  ])
                ]
              ]),
              $this->acf_image([
                'id' => $this->id( 'aa3', 100, 200, 150 ),
                'name' => 'img',
                'label' => 'Изобр.',
                'wrapper' => [ 'width' => 15 ],
                'preview_size' => 'medium',
                'conditional_logic' => [
                  array([
                    'field' => $this->id( 'aa3', 'prep_item_cond' ),
                    'operator' => '==empty',
                  ])
                ]
              ]),
              $this->acf_wysiwyg_editor([
                'id' => $this->id( 'aa3', 100, 200, 300 ),
                'name' => 'description',
                'label' => 'Описание детали',
                'wrapper' => [ 'width' => 85 ],
                'conditional_logic' => [
                  array([
                    'field' => $this->id( 'aa3', 'prep_item_cond' ),
                    'operator' => '==empty',
                  ])
                ]
              ]),
            ],
          ]),
        ], // sub_fields
      ]),
    ]; // $this->active_acf_3
  }


  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => $this->active_acf_1_title,
        'group_key' => $this->acf_group_key . '_aa1',
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      $this->register_acf_group([
        'title' => $this->active_acf_2_title,
        'group_key' => $this->acf_group_key . '_aa2',
        'fields' => $this->active_acf_2,
        'location' => $this->location,
      ]);
      $this->register_acf_group([
        'title' => $this->active_acf_3_title,
        'group_key' => $this->acf_group_key . '_aa3',
        'fields' => $this->active_acf_3,
        'location' => $this->location,
      ]);
    };
  }
  
} // class ACF_CONSTRUCTOR_PRODUCTS