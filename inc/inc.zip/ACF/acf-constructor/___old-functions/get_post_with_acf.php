<?php
/**
 * @param POST[ 'lang' ] or default lang
 * @param array $args
 *    @param int $default_post_id - post_id which use if there is no post_id with current lang
 *    @param int $post_id
 *    @param string $my_acf_alias - alias of acf from @global $my_acf: $my_acf->{$my_acf_alias}
 *                                  it is className alias where gets get_all_fields function
 *    @param boolean $get_only_acf (optional) default false
 *    @param boolean $get_only_post (optional) default false
 *    @param boolean $acf_in_acf_key (optional) default true
 * @param array $lg (optional) - uses if POST['lang'] doesn't set
 */
function __rest_get_post_with_acf($args, $lg='') {
  /* check if it is multilanguage site */
  $multi_lang = function_exists('pll_default_language');

  /* CONST */
  global $my_acf;
  $DEFAULT_POST_ID = isset($args['default_post_id']) ? $args['default_post_id'] : '';
  $my_acf_alias = isset($args['my_acf_alias']) ? $args['my_acf_alias'] : '';
  $get_only_acf = isset($args['get_only_acf']) ? $args['get_only_acf'] : false;
  $get_only_post = isset($args['get_only_post']) ? $args['get_only_post'] : false;
  $acf_in_acf_key = isset($args['acf_in_acf_key']) ? $args['acf_in_acf_key'] : true;
  isset($args['post_id']) ? 1 : $args['post_id'] = '';

  $lang = null;
  if ($multi_lang) {
    # define lang
    if (isset($_POST['lang'])) { 
      $lang = $_POST['lang'];
    } else if ($lg) {
      $lang = $lg;
    } else {
      $lang = pll_default_language();
    }

    # if post_id is set - use it
    if ($args['post_id']) {
      $post_id = $args['post_id'];
    }
    # if post_id is not set
    else {
      $post_id = pll_get_post($DEFAULT_POST_ID, $lang);
      // if post with this lang doesn't exist - return default post
      if (!$post_id) $post_id = $DEFAULT_POST_ID;
    }

  # if NOT milty lang
  } else if ($args['post_id']) {
    $post_id = $args['post_id'];

  } else {
    if ($DEFAULT_POST_ID) $post_id = $DEFAULT_POST_ID;
  }

  if (!isset($post_id)) {
    $post_id = get_the_id();
    // if (!$post_id) trigger_error('There is no $post_id. You have to set "default_post_id" or "post_id"<br>', E_USER_ERROR);
    if (!$post_id) return (object) [];
  }

  $WP_Post = get_post($post_id);


  #1. Get all post data
  if (!$get_only_acf) {
    #1.1 if get ACF
    if ($my_acf_alias) {
      if ($get_only_post) {
        $returnPost = $WP_Post;
      }
      else {
        #1.1.1 if acf in acf key // acf->[acf...]
        if ($acf_in_acf_key) {
          $returnPost = $WP_Post;
          $returnPost->acf = $my_acf->{$my_acf_alias}->get_all_fields($post_id, $lang);
        }
        #1.1.2 if acf in post_data
        else {
          $returnPost = (object) array_merge(
            (array) $WP_Post,
            (array) $my_acf->{$my_acf_alias}->get_all_fields($post_id, $lang)
          );
        }
      }
    }
    #1.2 if get ONLY post_data
    else {
      $returnPost = $WP_Post;
    }



  #2. Get only ACF
  } else {
    $returnPost = (object) [];
    if (!isset($args['acf_in_acf_key'])) $acf_in_acf_key = false;
    if (!$my_acf_alias) {
      // return $returnPost;
    }
    else {
      #2.1 if acf in acf key // acf->[acf...]
      if ($acf_in_acf_key) {
        $returnPost->acf = $my_acf->{$my_acf_alias}->get_all_fields($post_id, $lang);
      }
      #2.2 if acf in post_data
      else {
        $returnPost = $my_acf->{$my_acf_alias}->get_all_fields($post_id, $lang);
      }
    }

  }


  if (!$get_only_acf) {
    /***** DEFINE porops *****/
    /* SET current_post_title*/
      $pt = [];
      $title = get_field('page_title', $post_id);
      if ($title && $title['text']) {
        $class = $title['class']? "class='" . $title['class'] . "'" : '';
        $style = $title['style']? "style='" . $title['style'] . "'" : '';
        $text = $title['text'];
        $pt = [
          'text' => $title['text'],
          'class' => $title['class'],
          'style' => $title['style'],
          'styled_text' => "<span $class $style>$text</span>",
        ];
      }
      else {
        $title = $WP_Post->post_title;
        $pt = [
          'text' => $title,
          'class' => '',
          'style' => '',
          'styled_text' => "<span>$title</span>",
        ];
      }
      $returnPost->current_post_title = $pt;
  
    /* SET breadcrumb_title*/
      $brt = $pt['text'];
      $br_title = get_field('breadcrumb_title', $post_id);
      if ( $br_title ) $brt = $br_title;
  
    /***** CONST adding props *****/
    $returnPost->breadcrumb_title = $brt;
    $returnPost->url = get_permalink( $WP_Post->ID );
  }

  /***** CONST adding props *****/
  $returnPost->ID = $post_id;
  $returnPost->lang = $lang;
  

  return $returnPost;
}