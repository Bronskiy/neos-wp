<?php 

/**
 * @param Array $args - the same as in get__breadcrumbs_array function
 */
function print_vue_acf_breadcrumbs($args=[], $jsObjName='__wpBreadcrumbs__') {
  $breadcrumbs = get__breadcrumbs_array($args);
  $print_only_js = isset($args['print_only_js'])? $args['print_only_js'] : false;
  u_add_php_object_to_js($jsObjName, $breadcrumbs);
  ?>

    <ul data-remove-onload><?php
      foreach ($breadcrumbs as $v) {
        echo "<li><a href=". $v['href'] .">". strip_tags($v['text']) ."</a></li>";
      }
    ?></ul>
  <?php if (!$print_only_js) { ?>
    <v-breadcrumbs class="pl-0" :items="__wpBreadcrumbs__" divider=">">
      <template v-slot:divider>
        <v-icon>mdi-chevron-right</v-icon>
      </template>
    </v-breadcrumbs>
  <?php } ?>

<?php }