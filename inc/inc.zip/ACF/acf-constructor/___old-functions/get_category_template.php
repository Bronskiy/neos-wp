<?php

/**
 * @param Boolean POST['$_POST'] is the $_POST set in other places
 * @param String POST['lang'] or default lang
 * @param Boolean POST['all'] get all terms default true
 * @param String POST['catName'] taxonomy name
 * @param Boolean POST['rest'] default = true
 */
function __rest_get_categories($args=[]) {
  $locPOST = $_POST;
  if (isset($args['rest']) && !$args['rest']) $locPOST = $args;
  else $locPOST = array_merge($args, $locPOST);

  $get_acf = isset($args['get_acf'])? $args['get_acf'] : true;

  $lang = isset($locPOST['lang']) ? $locPOST['lang'] : u_get_current_lang();
  $cat_name = isset($locPOST['catName']) ? $locPOST['catName'] : trigger_error('catName is not set!', E_USER_ERROR);
  $all = isset($locPOST['all']) ? $locPOST['all'] : true;

  if ($all) {
    $terms = get_terms($cat_name);
    return $get_acf? u_terms__add_taxonomy_acf_to_WP_Term($terms) : $terms;
  }
  else {
  }
}
