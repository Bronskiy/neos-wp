<?php

function print_vue_acf_main_event_info($page_acf=null) {
  if (!isset($page_acf)) $page_acf = $GLOBALS["_THIS_PAGE"]->acf;

  print_vue_acf_calendar([
    'dates' => array_merge((array)$page_acf->dates, (array)$page_acf->price),
    'js_object_name' => '_event_dates',
    'add_only_js' => 1,
  ]);
  print_vue_acf_timetable([
    'timetable' => $page_acf->timetable,
    'dates' => $page_acf->dates,
    'js_object_name' => '_event_timetable',
    'add_only_js' => 1,
  ]);
  print_vue_acf_map_card([
    'map' => $page_acf->map,
    'js_object_name' => '_event_map',
    'add_only_js' => 1,
  ]);

  ?>
    <main-event-info-block
      js-calendar-object-name="_event_dates"
      js-timetable-object-name="_event_timetable"
      js-map-card-object-name="_event_map"
    >
    </main-event-info-block>
  <?php
}