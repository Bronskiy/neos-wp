<?php

function print_vue_acf_map_card($args=[]) {
  $map = isset($args['map'])? $args['map'] : trigger_error('$args[\'map\'] in print_vue_acf_calendar didn\'t set', E_USER_ERROR);
  $js_object_name = isset($args['js_object_name'])? $args['js_object_name'] : trigger_error('$args[\'js_object_name\'] in print_vue_acf_gallery_2 didn\'t set', E_USER_ERROR);
  $js_is_loaded = isset($args['js_is_loaded'])? $args['js_is_loaded'] : 0;
  $add_only_js = isset($args['add_only_js'])? $args['add_only_js'] : 0;

  if (!$js_is_loaded) u_add_php_object_to_js($js_object_name, $map);

  if (!$add_only_js) { ?>
    <map-card
      js-map-card-object-name="<?php echo $js_object_name; ?>"
    ></map-card>
  <?php }

}