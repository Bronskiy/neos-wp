<?php

function print_vue_acf_timetable($args=[]) {
  $dates = isset($args['dates'])? $args['dates'] : trigger_error('$args[\'dates\'] in print_vue_acf_calendar didn\'t set', E_USER_ERROR);
  $timetable = isset($args['timetable'])? $args['timetable'] : trigger_error('$args[\'timetable\'] in print_vue_acf_calendar didn\'t set', E_USER_ERROR);
  $js_object_name = isset($args['js_object_name'])? $args['js_object_name'] : trigger_error('$args[\'js_object_name\'] in print_vue_acf_gallery_2 didn\'t set', E_USER_ERROR);
  $js_is_loaded = isset($args['js_is_loaded'])? $args['js_is_loaded'] : 0;
  $add_only_js = isset($args['add_only_js'])? $args['add_only_js'] : 0;

  if (!$js_is_loaded) {
    $timetableObj = (object) array_merge(
      $dates,
      [
        'startDate' => u_dates__ddmmyyyy_to_ISO8601($dates['start_date']),
        'endDate' => u_dates__ddmmyyyy_to_ISO8601($dates['end_date']),
      ],
      $timetable
    );
    u_add_php_object_to_js($js_object_name, $timetableObj);
  }

  if (!$add_only_js) { ?>
    <timetable js-timetable-object-name="<?php echo $js_object_name; ?>"></timetable>

    <v-dialog
      v-model="$store.state.showHideContent.calendarDialog"
      fullscreen
      hide-overlay
      transition="dialog-bottom-transition"
    >
      <timetable js-timetable-object-name="<?php echo $js_object_name; ?>" fullscreen></timetable>
    </v-dialog>
  <?php }

}