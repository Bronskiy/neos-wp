<?php
/***
  http://wp-vue/wp-json/myrest/v1/get_feedbacks
***/

/**
 * @param Boolean POST['$_POST'] is the $_POST set in other places
 * @param Boolean POST['lang'] or default lang
 * @param Number POST['page'] default 1
 * @param Number POST['postsPerPage'] default 10
 * @param String POST['search']
 * @param String POST['taxName']
 * @param String POST['catrel'] = OR | AND // default OR
 * @param Number POST['catid'] default []
 * @param String POST['catids'] default [] Example: 12-43-34-5
 * @param String POST['postType']
 * @param String POST['acfAlias']
 * @param Boolean POST['rest'] default = true
 * @param Boolean POST['getACF'] default = true
 * @param Boolean POST['get_nothing'] default = false
 * @param Number POST['postid'] id of post I want to get
 * @param Number POST['endId'] id of end post
 * @param String POST['layout'] pages (default) | scroll
 * @param Number POST['getPostsCount'] default = 0
 */
function __rest_get_post_template($_args=[]) {
  $locPOST = $_POST;
  if (isset($_args['rest']) && !$_args['rest']) $locPOST = $_args;
  else $locPOST = array_merge($_args, $locPOST);

  /* MUST HAVE:start */
  $postType = $locPOST['postType'] = isset($locPOST['postType'])? $locPOST['postType'] : trigger_error('$locPOST[postType] || $_args[postType] is not defined!', E_USER_ERROR);
  $acfAlias = $locPOST['acfAlias'] = isset($locPOST['acfAlias'])? $locPOST['acfAlias'] : trigger_error('$locPOST[acfAlias] || $_args[acfAlias] is not defined!', E_USER_ERROR);
  $getACF = $locPOST['getACF'] = isset($locPOST['getACF'])? $locPOST['getACF'] : true;
  /* MUST HAVE:end */

  $lang = $locPOST['lang'] = isset($locPOST['lang']) ? $locPOST['lang'] : u_get_current_lang();
  $get_nothing = $locPOST['get_nothing'] = isset($locPOST['get_nothing']) ? +$locPOST['get_nothing'] : false;


  if ($get_nothing) {
    return __rgpt_get_posts_set(
      $locPOST,
      (object) [
        'posts_per_page' => 0,
        'found_posts' => 0,
        'max_num_pages' => 0,
      ],
      []
    );
  }


  $page = $locPOST['page'] = isset($locPOST['page']) ? +$locPOST['page'] : 1;
  $postsPerPage = $locPOST['postsPerPage'] = isset($locPOST['postsPerPage']) ? +$locPOST['postsPerPage'] : 10;
  // $search = $locPOST['search'] = isset($locPOST['search'])? $locPOST['search'] : 0;

  $post_id = $locPOST['postid'] = isset($locPOST['postid'])? $locPOST['postid'] : '';

  $taxName = $locPOST['taxName'] = isset($locPOST['taxName'])? $locPOST['taxName'] : '';
  $catrel = $locPOST['catrel'] = isset($locPOST['catrel'])? $locPOST['catrel'] : 'OR';
  $locPOST['catids'] = __rgpt_get_cat_ids($locPOST);

  $locPOST['endId'] = isset($locPOST['endId'])? $locPOST['endId'] : false;
  $locPOST['getPostsCount'] = isset($locPOST['getPostsCount'])? $locPOST['getPostsCount'] : 0;
  $layout = $locPOST['layout'] = isset($locPOST['layout'])? $locPOST['layout'] : 'pages';

  
  $got_posts = [];
  /*** SCROLL ****/
  if ($layout == 'scroll') {
    $WP_Query = __rgpt_get_post_ids__scroll_layout($locPOST);
    $got_posts = $WP_Query->posts;
  }

  /**** PAGES ****/
  else {
    $WP_Query = __rgpt_get_post_ids__page_layout($locPOST);
    $got_posts = $WP_Query->posts;
  }


  return __rgpt_get_posts_set($locPOST, $WP_Query, $got_posts);
}

















































function __rgpt_get_post_ids__page_layout( $props ) {
  $postType = $props['postType'];
  $page = $props['page'];
  $postsPerPage = $props['postsPerPage'];
  $postType = $props['postType'];
  $post_id = $props['postid'];
  $catids = $props['catids'];
  $taxName = $props['taxName'];
  $catrel = $props['catrel'];

  $props = [
    'post_type'       => $postType,
    'paged'           => $page,
    'posts_per_page'  => $postsPerPage,
    'fields'          => 'ids',
    'meta_key'        => 'post_order',
    'orderby'         => 'meta_value_num',
    'order'           => 'ASC',
  ];

  if (isset($post_id)) $props['p'] = $post_id;

  if ($taxName && $catids) {
    $props['tax_query'] = ['relation' => $catrel];

    foreach ($catids as $id) {
      $props['tax_query'][] = [
        'taxonomy' => $taxName,
        'field' => 'id',
        'terms' => $id,
      ];
    }
  }

  $WP_Query = new WP_Query($props);
  return $WP_Query;
}










function __rgpt_get_post_ids__scroll_layout( $props ) {
  $post_id = $locPOST['postid'];
  $catids = $props['catids'];
  $taxName = $props['taxName'];
  $catrel = $props['catrel'];
  $postType = $props['postType'];
  $acfAlias = $props['acfAlias'];
  $getACF = $props['getACF'];
  $endId = $props['endId'];
  $getPostsCount = $props['getPostsCount'];

  $args = [
    'post_type'       => $postType,
    'fields'          => 'ids',
    'posts_per_page'  => -1,
    'meta_key'        => 'post_order',
    'orderby'         => 'meta_value_num',
    'order'           => 'ASC',
  ];
  if (isset($post_id)) $args['p'] = $post_id;

  if ($taxName && $catids) {
    $args['tax_query'] = ['relation' => $catrel];

    foreach ($catids as $id) {
      $args['tax_query'][] = [
        'taxonomy' => $taxName,
        'field' => 'id',
        'terms' => $id,
      ];
    }
  }

  $WP_Query = new WP_Query($args);
  
  $start = array_search($endId, $WP_Query->posts) + 1;
  $WP_Query->posts = array_slice($WP_Query->posts, $start, $getPostsCount);
  return $WP_Query;
}











function __rgpt_get_posts_set( $props, $WP_Query, $got_posts ) {
  $acfAlias = $props['acfAlias'];
  $getACF = $props['getACF'];
  $lang = $props['lang'];
  $page = $props['page'];

  $posts_set = (object) [
    'posts' => [],
    'postsPerPage' => +$WP_Query->posts_per_page,
    'postsCount' => +$WP_Query->found_posts,
    'pageCount' => +$WP_Query->max_num_pages,
    'page' => $page,
  ];
  
  foreach ($got_posts as $key => $id) {
    /* if ($WP_Post == post_id) get post */
    // if (is_numeric($WP_Post) || is_string($WP_Post)) $WP_Post = get_post( $WP_Post );

    if ($getACF) {
      $posts_set->posts["_$id"] = __rest_get_post_with_acf([
        'default_post_id' => $id,
        'my_acf_alias' => $acfAlias,
        'get_only_acf' => false,
        'acf_in_acf_key' => true,
      ], u_get_current_lang());
    }

    else {
      $posts_set->posts["_$id"] = __rest_get_post_with_acf([
        'default_post_id' => $id,
        'my_acf_alias' => $acfAlias,
        'get_only_acf' => false,
        'get_only_post' => true,
      ], u_get_current_lang());
    }

  }

  return $posts_set;
}























function __rgpt_get_cat_ids( $props ) {
  $taxName = $props['taxName'];
  $catid = isset($props['catid'])? $props['catid'] : '';
  $catids = isset($props['catids'])? $props['catids'] : '';

  /* catids is primary */
  $catids = $catids? $catids : $catid;
  $x = explode('-', $catids);
  global $_temp_; $_temp_ = 0;

  /* if there is STRING among ids - set catids=[] */
  $catids = array_filter($x, function($id) {
    global $_temp_;
    if (!is_numeric($id)) { $_temp_ = 1; }
    return is_numeric($id);
  });
  if ($_temp_ > 0) $catids = [];

  /* remove false ids */
  if ($catids) {
    $cats = __rest_get_categories([
      'rest' => false,
      'catName' => $taxName,
      'get_acf' => false,
    ]);
    $cats = u_arrays__level_up($cats);
    foreach ($catids as $n => $id) {
      if (!in_array($id, $cats)) unset($catids[$n]);
    }
  }

  return $catids;
}