<?php

/**
 * @param Object $args['gallery']* - acf->gallery
 * @param Array  $args['display_photo_count']
 *    @example 'display_photo_count' => [0 => 12]
 *    @example 'display_photo_count' => [0 => 9, 576 => 12]
 * @param Number $args['current_photo']
 * @param String $args['more_btn_text'] // if set more btn appears with apointed text
 * @-param $args['row_class']
 */
function print_vue_acf_gallery($args=[]) {
  if (!$args || !$args['gallery']) return;

  $gallery = isset($args['gallery'])? $args['gallery'] : trigger_error('$args[\'gallery\'] in print_vue_acf_gallery didn\'t set', E_USER_ERROR);
  $js_object_name = isset($args['js_object_name'])? $args['js_object_name'] : trigger_error('$args[\'js_object_name\'] in print_vue_acf_gallery_2 didn\'t set', E_USER_ERROR);
  $js_is_loaded = isset($args['js_is_loaded'])? $args['js_is_loaded'] : 0;


  


  if (!$js_is_loaded) {
    $photos = [];
    foreach ($gallery as $n => $v) {
      $photos[] = [
        'sizes' => $v['sizes'],
        'alt' => $v['alt'],
        'description' => $v['description'],
        'caption' => $v['caption'],
        // 'title' => $v['caption'],
      ];
    }
    u_add_php_object_to_js($js_object_name, $photos);
  }

  ?>
    <gallery
      js-gallery-object-name="<?php echo $js_object_name; ?>"
      :display-photo-count='<?php echo isset($args['display_photo_count'])? json_encode($args['display_photo_count'], JSON_OBJECT_AS_ARRAY) : "[]" ?>'
      :initial-photo-num=<?php echo isset($args['current_photo'])? strval($args['current_photo']) : 0 ?>
      more-btn-text="<?php echo isset($args['more_btn_text'])? $args['more_btn_text'] : '' ?>"
    ></gallery>
  <?php
}
