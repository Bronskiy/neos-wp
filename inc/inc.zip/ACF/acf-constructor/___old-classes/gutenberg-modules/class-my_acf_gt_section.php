<?php

class MY_ACF_GT_SECTION extends MY_ACF {

  public $acf_group_key = 'gt_section_acf_group_key';

  public $active_acf;

  public $acf;

  public $acf_keys;

  public $block_name = 'section';

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'gt_section_';

  public function register() {
    $this->acf = (object) [];

    $this->register_gutenberg_block();

    $this->active_acf = [
      $this->acf_color([
        'id' => 10, /* do NOT change*/
        'name' => 'bgr_color',
        'label' => 'Section background color',
        'instructions' => 'Default colors:
          <br>#f4f4f4 (gray-light-1)
          <br>#fafafa (gray-light-2)
          <br>#ffffff (white)
        ',
      ]),
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }





  private function register_gutenberg_block() {
    add_action('acf/init', function() {
      // register a section block
      acf_register_block([
        'name'				=> $this->block_name,
        'title'				=> __('Section'),
        'description'		=> __('Sections are used as marks of section start and break with new section'),
        'render_callback'	=> 'my_acf_block_render_callback',
        'category'			=> 'layout',
        'icon'				=> 'editor-table',
        'keywords'			=> [ $this->block_name ], /* for searching in blocks */
      ]);
    });

    function my_acf_block_render_callback( $block ) {
      // convert name ("acf/blockName") into path friendly slug ("blockName")
      $slug = str_replace('acf/', '', $block['name']);
      // include a templates part from within the "templates/gutenberg-blocks" folder
      if( file_exists( get_theme_file_path("inc/ACF/templates/gutenberg-blocks/content-{$slug}.php") ) ) {
        include( get_theme_file_path("inc/ACF/templates/gutenberg-blocks/content-{$slug}.php") );
      }
    }
  }




  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      acf_add_local_field_group([
        'key' => $this->acf_group_key,
        'title' => 'Настройки формы',
        'fields' => $this->active_acf,

        'location' => [
          array(
            [
              'param' => 'block',
              'operator' => '==',
              'value' => 'acf/' . $this->block_name,
            ],
          ),
        ],
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
      ]);
    };
  }

}