<?php
	/**
	 * Block Name: Section
	 * This is the template that displays the section block.
	 */
	$bgr_color = get_field('bgr_color');
?>

<div class="gb-section" style="background-color: <?php echo $bgr_color ?>">
	<span><b>Section</b> background color: <b><?php echo $bgr_color ?></b></span>
</div>


<style type="text/css">
	.gb-section {
		padding: 8px;
		border: 4px solid #000;
		border-bottom: 0;
	}
	.gb-section span {
	}
</style>