<?php

class MY_ACF_GLOBAL_S_SETTINGS extends MY_ACF {

  public $acf_group_key = MY_CPT_S_SETTINGS . '_acf_group_key';

  public $post_type = MY_CPT_S_SETTINGS;

  public $active_acf_1; /* Общее */
  // public $active_acf_2; /* Меню */
  // public $active_acf_3; /* Форма */

  public $location;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'g_s_settings';

  public function register() {
    $this->acf = (object) [];

    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => MY_CPT_S_SETTINGS,
        ],
        [
          'param' => 'page',
          'operator' => '==',
          'value' => get_option('__global_s_settings_post_id__'),
        ],
      ),
    ];

    /* Общее */
    $this->active_acf_1 = [
      $this->acf_radio([
        'id' =>  $this->id('aa1_', 10),
        'name' => 'display_feedback',
        'label' => 'Показывать ли раздел с отзывами?',
        'choices' => [
          0 => 'Нет',
          1 => 'Да',
        ],
        'default_value' => 1
      ]),
    ];



    /* Меню */
    $this->active_acf_2 = [
      $this->acf_text([
        'id' => $this->id('aa2', 10),
        'name' => 'main_menu_name',
        'label' => 'Имя главного меню',
        'instructions' => 'Должно совпадать с именем меню, указанного здесь: "Внешний вид" ->"Меню" ->"Название меню"',
      ]),
    ];

    // /* Форма */
    // $this->active_acf_3 = [
    //   $this->acf_form_set([
    //     'id' => $this->id('aa3_', 10),
    //   ]),
    // ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }






  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => 'Общее',
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      
      $this->register_acf_group([
        'title' => 'Меню',
        'group_key' => $this->acf_group_key.'2',
        'fields' => $this->active_acf_2,
        'location' => $this->location,
      ]);

      // $this->register_acf_group([
      //   'title' => 'Форма',
      //   'group_key' => $this->acf_group_key.'3',
      //   'fields' => $this->active_acf_3,
      //   'location' => $this->location,
      // ]);
    };
  }



















  public function get_all_fields($post_id, $lang='') {
    if (__ACF_DEBUG__) echo " ___acf_global_s_settings___ <br>\n";
    $o = (object) [];

    foreach ($this->active_acf_1 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    // foreach ($this->active_acf_2 as $filed) {
    //   $acf_name = $filed['name'];
    //   $o->{$acf_name} = get_field($acf_name, $post_id);
    // }
    // foreach ($this->active_acf_3 as $filed) {
    //   $acf_name = $filed['name'];
    //   $o->{$acf_name} = get_field($acf_name, $post_id);
    // }
    return $o;
  }


}