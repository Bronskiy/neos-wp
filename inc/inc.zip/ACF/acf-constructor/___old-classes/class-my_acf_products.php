<?php

class MY_ACF_PRODUCTS extends MY_ACF {

  public $acf_group_key = MY_CPT_PRODUCTS . '_acf_group_key';

  public $post_type = MY_CPT_PRODUCTS;

  public $active_acf_1; /* Контент */
  public $active_acf_2; /* Карточка услуги в архиве */
  public $active_acf_3; /* Форма */

  public $location;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'products_';

  public function register() {
    $this->acf = (object) [];
    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => $this->post_type,
        ],
      ),
    ];

    /* Контент */
    $this->active_acf_1 = [ 
    ];

    /* Карточка услуги в архиве */
    $this->active_acf_2 = [
    ];

    /* Форма */
    $this->active_acf_3 = [
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }












  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => 'Контент страницы',
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      
      $this->register_acf_group([
        'title' => 'Карточка услуги в архиве',
        'group_key' => $this->acf_group_key.'2',
        'fields' => $this->active_acf_2,
        'location' => $this->location,
      ]);

      $this->register_acf_group([
        'title' => 'Форма',
        'group_key' => $this->acf_group_key.'3',
        'fields' => $this->active_acf_3,
        'location' => $this->location,
      ]);
    };
  }
















  public function get_all_fields($post_id, $lang='') {
    if (__ACF_DEBUG__) echo " ___acf_products___ <br>\n";
    $o = (object) [];

    foreach ($this->active_acf_1 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    foreach ($this->active_acf_2 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    foreach ($this->active_acf_3 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    return $o;
  }


}