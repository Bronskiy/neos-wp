<?php

class MY_ACF {

  public $acf_set;

  # acf_names sum = wp_postmeta->meta_key;
  # key = wp_postmeta->meta_value
  public $uniqueId = 0;

  public function register() {
    global $my_acf;
    $my_acf = $this;

    $this->add_acf_css_to_admin();

    if (!__IN__DEV__) {
      $this->remove_acf_from_admin();
    }

    $this->acf_set = (object) [
      // S_SETTINGS_ALIAS => (object) [
      //   'require' => 'class-my_acf_global_s_settings.php',
      //   'class' => 'MY_ACF_GLOBAL_S_SETTINGS',
      // ],
      // PRODUCTS_ALIAS => (object) [
      //   'require' => 'class-my_acf_products.php',
      //   'class' => 'MY_ACF_PRODUCTS',
      // ],
      CONTACTS_ALIAS => (object) [
        'require' => 'class-my_acf_contacts.php',
        'class' => 'MY_ACF_Contacts',
      ],
      // FORMS_ALIAS => (object) [
      //   'require' => 'class-my_acf_forms.php',
      //   'class' => 'MY_ACF_FORMS',
      // ],
      // '_where_to_send_emails_' => (object) [
      //   'require' => 'class-my_acf_where_to_send_emails.php',
      //   'class' => 'MY_ACF_WHERE_TO_SEND_EMAILS',
      // ],
      // SEO_ALIAS => (object) [
      //   'require' => 'class-my_acf_SEO.php',
      //   'class' => 'MY_ACF_SEO',
      // ],

      /* GUTENBERG */
      // 'gt_section' => (object) [
      //   'require' => 'gutenberg-modules/class-my_acf_gt_section.php',
      //   'class' => 'MY_ACF_GT_SECTION',
      // ],
    ];

    
    foreach ($this->acf_set as $k => $v) {
      require_once $v->require;
      $class = new $v->class;
      $class->register();
      $this->{$k} = $class;
    }
  }





  /*** FUNCTIONS ***/
  public function uniqueKey($id='') {
    $this->uniqueId = $this->uniqueId + 1;
    if ($id) {
      return $this->uniqueIdPrefix .'_'. $id;
    } else {
      trigger_error("Не указано 'id' для ACF", E_USER_ERROR);
    }
  }


  public function id( $idArray ) {
    if (!is_array($idArray)) $idArray = func_get_args();

    $id = array_shift($idArray);
    foreach ($idArray as $subId) {
      $id .= "_$subId";
    }
    return $id;
  }


  
  private function remove_acf_from_admin() {
    add_filter('acf/settings/show_admin', '__return_false');
  }



  /**
   * parse 2 args and set default ACF name
   */
  private function get_args( $id_or_args=[], $args=[], $acfDefaultName ) {
    if (is_int($id_or_args) || is_string($id_or_args)) $args['id'] = $id_or_args;
    else if (is_array($id_or_args)) $args = $id_or_args;

    if (!isset($args['name'])) $args['name'] = $acfDefaultName;
    $this->acf->{$args['name']} = $args['name'];

    if (!isset($args['id']) || !$args['id']) trigger_error("Не указано 'id' для ACF ({$this->acf_group_key})", E_USER_ERROR);
    else $args['id'] = $this->uniqueKey($args['id']);

    return $args;
  }




  private function add_acf_css_to_admin() {
    add_action( 'admin_enqueue_scripts', function(){
      wp_enqueue_style( 'admin_acf_css', get_template_directory_uri() . '/inc/ACF/admin-acf-styles.css', false, '1.0.1' );
    });
  }

  function label($string, $acf_name) {
    return __IN__DEV__?
      $string . " <i class='acf_field_name'>($acf_name)</i>"
      : $string
    ;
  }

  function register_acf_group($args) {
    acf_add_local_field_group([
      'key' => isset($args['group_key'])? $args['group_key'] : trigger_error('group_key is not set!!!', E_USER_ERROR),
      'title' => isset($args['title'])? $args['title'] : trigger_error('title is not set!!!', E_USER_ERROR),
      'fields' => isset($args['fields'])? $args['fields'] : trigger_error('fields is not set!!!', E_USER_ERROR),
      'location' => isset($args['location'])? $args['location'] : trigger_error('location is not set!!!', E_USER_ERROR),
      'label_placement' => 'top',
      'instruction_placement' => 'label',
      'active' => true,
    ]);
  }


  public $data_attrs_use_instr = '
    Позволяет выполнять определенные действия при нажатии (указать можно несколько, разделив пробелом)<br>
    <b>data-open-privacy-policy-dialog</b> - открывает окно с политикой конфиденциальности<br>
    <b>data-open-call-form-dialog</b> - открывает окно с формой заказа обратного звонка<br>
    <b>data-open-main-form-dialog</b> - открывает окно c формой заказа услуг<br>
    <i>Если дата-атрибут указан, то ссылка не будет работать, даже если указан URL</i>
  ';


























  /*** ACF FUNCTIONS ***/
  /* https://www.advancedcustomfields.com/resources/register-fields-via-php/ */

  function acf_text( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'text');
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Text', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => isset($args['type']) ? $args['type'] : 'text',
      'required' => isset($args['required'])? $args['required'] : 0,
      'default_value' => isset($args['default_value'])? $args['default_value'] : "",
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
    ];
  }





  function acf_message( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, '');
    return [
      'key' => $args['id'],
      'label' => isset($args['label'])? $args['label'] : ' ',
      'type' => 'message',
      'message' => isset($args['message'])? $args['message'] : 'Текст не указан!!!',
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'new_lines' => isset($args['new_lines'])? $args['new_lines'] : 'br',
    ];
  }





  function acf_learm_more_btn_text( $id='' ) {
    $this->acf->learm_more_btn_text = 'learm_more_btn_text';
    return $this->acf_text([
      "id" => isset($id) ? $this->uniqueKey($id) : $this->uniqueKey(),
      // 'label' => 'Text of "Learn More" button',
      'label' => 'Текст кнпоки "Подробнее"',
      'default_value' => 'Подробнее',
      'name' => $this->acf->learm_more_btn_text,
    ]);
  }





  function acf_order( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'post_order');

    return $this->acf_text([
      'id' => $args['id'],
      'label' => isset($args['label']) ? $args['label'] : 'Порядок отображения постов',
      'name' => $args['name'],
      'type' => 'number',
      'instr' => isset($args['instr']) ? $args['instr'] : 'От <b>0</b> до <b>999 999 999</b>',
      // 'instr' => isset($args['instr']) ? $args['instr'] : '
      //   Set order of display.<br>
      //   It is set from <b>0</b> to <b>999 999 999</b>. Smaller value is shown earlier.<br>
      //   It is recommended to set values with interval = 100 so that it could be possible easy set other value between.
      // ',
      'default_value' => 999999,
      'required' => isset($args['required'])? $args['required'] : 0,
    ]);
  }





  function acf_gallery( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'gallery');

    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Галерея', $args['name']),
      'name' => $args['name'],
      'type' => 'gallery',
      'instructions' => 'Добавьте фотографии к галерее',
      'return_format' => 'array',
      'preview_size' => 'medium',
      'insert' => 'append',
      'library' => 'all',
      'mime_types' => 'jpg, jpeg, png',
    ];
  }





  function acf_gallery_set( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'gallery');
    $id = $args['id'];

    return $this->acf_group([
      'id' => $id,
      'name' => 'gallery_set',
      'label' => 'Настройка галереи',
      'layout' => 'row',
      'sub_fields' => [
        $this->acf_textarea([
          'id' => $this->id([$id, 10]),
          'name' => 'title',
          'label' => 'Заголовок',
          'rows' => 3,
        ]),
        $this->acf_text([
          'id' => $this->id([$id, 20]),
          'name' => 'more_btn_text',
          'label' => 'Текст кнопки "Показать больше"',
          'default_value' => 'Смотреть все',
        ]),
        $this->acf_gallery([
          'id' => $this->id([$id, 30]),
          'label' => 'Галерея',
        ]),
      ],
    ]);
  }
  


  
  
  function acf_short_desc( $id='', $instr='' ) {
    $this->acf->short_desc = 'short_desc';
    return $this->acf_textarea([
      'id' => isset($id) ? $this->uniqueKey($id) : $this->uniqueKey(),
      'label' => 'Short description',
      'name' => $this->acf->short_desc,
      'rows' => 6,
      'instr' => $instr,
    ]);
  }
  
  function acf_line_desc( $id='', $instr='' ) {
    $this->acf->desc = 'description';
    return $this->acf_text([
      'id' => isset($id) ? $this->uniqueKey($id) : $this->uniqueKey(),
      'label' => 'Description',
      'name' => $this->acf->desc,
      'instr' => $instr,
    ]);
  }

  function acf_class_style_text( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'text');
    $id = $args['id'];
    return $this->acf_group([
      'id' => $id,
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Текст',
      'instr' => isset($args['instr'])? $args['instr'] : '',
      'sub_fields' => [
        $this->acf_textarea([
          'id' => $this->id([$id, 10]),
          'name' => 'text',
          'label' => 'Текст',
          'rows' => 3,
          'wrapper' => array(
            'width' => '60',
            'class' => '',
          ),
        ]),
        $this->acf_textarea([
          'id' => $this->id([$id, 20]),
          'name' => 'class',
          'label' => 'class',
          'new_lines' => '',
          'rows' => 3,
        ]),
        $this->acf_textarea([
          'id' => $this->id([$id, 30]),
          'name' => 'style',
          'label' => 'style',
          'new_lines' => '',
          'rows' => 3,
        ]),
      ],
    ]);
  }

  function acf_class_style_block( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'styles');
    $id = $args['id'];
    return $this->acf_group([
      'id' => $id,
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Стили',
      'instr' => isset($args['instr'])? $args['instr'] : '',
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
      'sub_fields' => [
        $this->acf_textarea([
          'id' => $this->id([$id, 20]),
          'name' => 'class',
          'label' => 'class',
          'new_lines' => '',
          'rows' => 3,
        ]),
        $this->acf_textarea([
          'id' => $this->id([$id, 30]),
          'name' => 'style',
          'label' => 'style',
          'new_lines' => '',
          'rows' => 3,
        ]),
      ],
    ]);
  }

  function acf_page_title( $id, $instr='' ) {
    return $this->acf_class_style_text([
      'id' => $id,
      'name' => 'page_title',
      'label' => 'Заголовок страницы',
      'instr' => $instr,
    ]);
  }

  function acf_page_subtitle( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'page_subtitles');
    $id = $args['id'];

    return $this->acf_repeater([
      'id' => $id,
      'name' => $args['name'],
      'label' => isset($args['label']) ? $args['label'] : 'Подзаголовок страницы',
      'instr' => isset($args['instr']) ? $args['instr'] : '',
      'layout' => 'block',
      'sub_fields' => [
        $this->acf_class_style_text([
          'id' => $this->id([$id, 100]),
          'name' => 'subtitle',
        ]),
      ],
    ]);
  }


  function li_prefix_field( $id='', $instr='' ) {
    $this->acf->li_prefix = 'li_prefix';
    return $this->acf_text([
      'id' => isset($id) ? $this->uniqueKey($id) : $this->uniqueKey(),
      'name' => $this->acf->li_prefix,
      'label' => 'Item name in list',
      'instr' => $instr,
    ]);
  }







  function acf_image( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'image');

    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Image', $args['name']),
      'name' => $args['name'],
      'type' => 'image',
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'preview_size' => isset($args['preview_size'])? $args['preview_size'] : 'thumbnail',
      'return_format' => 'array',
      'library' => isset($args['library']) ? $args['library'] : 'all',
      'min_width' => isset($args['min_width']) ? $args['min_width'] : 0,
      'min_height' => isset($args['min_height']) ? $args['min_height'] : 0,
      'min_size' => isset($args['min_size']) ? $args['min_size'] : 0,
      'max_width' => isset($args['max_width']) ? $args['max_width'] : 0,
      'max_height' => isset($args['max_height']) ? $args['max_height'] : 0,
      'max_size' => isset($args['max_size']) ? $args['max_size'] : 0,
      'mime_types' => isset($args['mime_types']) ? $args['mime_types'] : '',
    ];
  }






  function acf_date_time( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'date');

    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Дата', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => isset($args['type']) ? $args['type'] : 'date_time_picker', // time_picker | date_picker | time_picker
      'required' => isset($args['required'])? $args['required'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'display_format' => isset($args['display_format']) ? $args['display_format'] : 'd.m.Y H:i',
      'return_format' => isset($args['return_format']) ? $args['return_format'] : 'd.m.Y H:i',
			'first_day' => 1, // monday
    ];
  }





  function acf_start_end_date_time( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'date');
    $id = $args['id'];

    return $this->acf_group([
      'id' => $id,
      'label' => isset($args['label']) ? $args['label'] : 'Даты проведения мероприятия',
      'name' => 'dates',
      'sub_fields' => [
        $this->acf_date_time([
          'id' => $this->id([$id, 10]),
          'label' => 'Дата начала',
          'name' => 'start_date',
          'type' => 'date_picker',
          'display_format' => 'd.m.Y',
          'return_format' => 'd.m.Y',
          'required' => isset($args['start_date_required']) ? $args['start_date_required'] : true,
        ]),
        $this->acf_date_time([
          'id' => $this->id([$id, 20]),
          'label' => 'Время начала',
          'name' => 'start_time',
          'type' => 'time_picker',
          'display_format' => 'H:i',
          'return_format' => 'H:i',
        ]),
        $this->acf_textarea([
          'id' => $this->id([$id, 60]),
          'label' => 'Описание даты',
          'name' => 'date_descr',
          'rows' => 3,
        ]),
        $this->acf_date_time([
          'id' => $this->id([$id, 30]),
          'label' => 'Дата окончания',
          'name' => 'end_date',
          'type' => 'date_picker',
          'display_format' => 'd.m.Y',
          'return_format' => 'd.m.Y',
        ]),
        $this->acf_date_time([
          'id' => $this->id([$id, 40]),
          'label' => 'Время окончания',
          'name' => 'end_time',
          'type' => 'time_picker',
          'display_format' => 'H:i',
          'return_format' => 'H:i',
        ]),
        $this->acf_textarea([
          'id' => $this->id([$id, 50]),
          'label' => 'Описание времени',
          'name' => 'time_descr',
          'rows' => 3,
        ]),
      ]
    ]);
  }





  function acf_map( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'map');
    $id = $args['id'];

    isset($args['image'])? 0 : $args['image'] = 1;
    isset($args['icon_name'])? 0 : $args['icon_name'] = 1;

    return [
      $args['image']? $this->acf_image([
        'id' => $this->id([$id, 10]),
        'label' => 'Изображение карты',
      ]) : null,
      $args['icon_name']? $this->acf_text([
        'id' => $this->id([$id, 15]),
        'name' => 'icon_name',
        'label' => 'Имя иконки',
      ]) : null,
      $this->acf_textarea([
        'id' => $this->id([$id, 20]),
        'name' => 'location_name',
        'label' => 'Адрес/Название места',
        'rows' => 3,
      ]),
      $this->acf_text([
        'id' => $this->id([$id, 30]),
        'name' => 'coordinates',
        'label' => 'Координаты',
        'instr' => 'Пример: <b>41.413674, 2.150720</b>',
      ]),
      $this->acf_textarea([
        'id' => $this->id([$id, 40]),
        'name' => 'description',
        'label' => 'Описание места встречи',
        'rows' => 3,
      ]),
    ];
  }






  function acf_map_group( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'map');
    $id = $args['id'];

    $this->apps_id = $id .'_apps_';
    $this->apps_key = $this->uniqueKey( $this->apps_id );

    isset($args['image'])? 0 : $args['image'] = 1;
    isset($args['icon_name'])? 0 : $args['icon_name'] = 1;

    return $this->acf_group([
      'id' => $id,
      'label' => isset($args['label']) ? $args['label'] : 'Место проведения мероприятия',
      'name' => $args['name'],
      'layout' => 'row',
      'sub_fields' => array_merge($this->acf_map([
          'id' => $this->id([$id, 10]),
          'image' => $args['image'],
          'icon_name' => $args['icon_name'],
        ]), [
          // $this->acf_checkbox([
          //   'id' => $this->apps_id,
          //   'name' => 'apps',
          //   'label' => 'Где можно открыть карту',
          //   'choices' => [
          //     'google' => 'Google',
          //     'yandex' => 'Yandex',
          //     '2gis' => '2GIS',
          //   ],
          //   'default_value' => ['google', 'yandex']
          // ]),
          // $this->acf_group([
          //   'id' => $this->id([$id, 200]),
          //   'name' => 'search_set',
          //   'label' => 'Поисковые запросы',
          //   'layout' => 'row',
          //   'sub_fields' => [
          //     $this->acf_text([
          //       'conditional_logic' => [
          //         array([
          //           'field' => $this->apps_key,
          //           'operator' => '==',
          //           'value' => 'google',
          //         ]),
          //       ],
          //       'id' => $this->id([$id, 20, 10]),
          //       'name' => 'google',
          //       'label' => 'Поисковый запрос для Google',
          //     ]),
          //     $this->acf_text([
          //       'conditional_logic' => [
          //         array([
          //           'field' => $this->apps_key,
          //           'operator' => '==',
          //           'value' => 'yandex',
          //         ]),
          //       ],
          //       'id' => $this->id([$id, 20, 20]),
          //       'name' => 'yandex',
          //       'label' => 'Поисковый запрос для Yandex',
          //     ]),
          //     $this->acf_text([
          //       'conditional_logic' => [
          //         array([
          //           'field' => $this->apps_key,
          //           'operator' => '==',
          //           'value' => '2gis',
          //         ]),
          //       ],
          //       'id' => $this->id([$id, 20, 30]),
          //       'name' => '2gis',
          //       'label' => 'Поисковый запрос для 2GIS',
          //     ]),// acf_text
          //   ] // sub_fields
          // ]),
        ]),
      ]);
  }





  function acf_true_false( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'true_false');

    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'true_false', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => 'true_false',
      'required' => isset($args['required'])? $args['required'] : 0,
      'default_value' => isset($args['default_value'])? $args['default_value'] : 1,
      'message' => isset($args['message'])? $args['message'] : 'message is here',
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
    ];
  }





  function acf_group( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'group');
    
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Group', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => 'group',
      'required' => isset($args['required'])? $args['required'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'layout' => isset($args['layout']) ? $args['layout'] : 'table', // table (default) || block || row
      'sub_fields' => isset($args['sub_fields']) ? $args['sub_fields'] : [],
    ];
  }





  function acf_flexible_content( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'flexible_content');
    
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Flexible_content', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => 'flexible_content',
      'required' => isset($args['required'])? $args['required'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'layout' => isset($args['layout']) ? $args['layout'] : 'table', // table (default) || block || row
      'layouts' => isset($args['layouts']) ? $args['layouts'] : [],
    ];
  }





  function acf_taxonomy( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'taxonomy');
    
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Taxonomy', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
			'type' => 'taxonomy',
			'taxonomy' => isset($args['taxonomy']) ? $args['taxonomy'] : 'category',
      'field_type' => isset($args['field_type'])? $args['field_type'] : 'checkbox', // checkbox | ...
      'required' => isset($args['required'])? $args['required'] : 0,
      'return_format' => isset($args['return_format'])? $args['return_format'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'layout' => isset($args['layout']) ? $args['layout'] : 'table', // table (default) || block || row
      'sub_fields' => isset($args['sub_fields']) ? $args['sub_fields'] : [],
      'add_term' => isset($args['add_term']) ? $args['add_term'] : 1,
      'save_terms' => isset($args['save_terms']) ? $args['save_terms'] : 1,
      'load_terms' => isset($args['load_terms']) ? $args['load_terms'] : 1,
      'multiple' => isset($args['multiple']) ? $args['multiple'] : 0,
    ];
  }






  function acf_textarea( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'textarea');
    
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Text', $args['name']),
      'name' => $args['name'],
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'type' => 'textarea',
      'rows' => isset($args['rows']) ? $args['rows'] : 8,
      'required' => isset($args['required'])? $args['required'] : 0,
      'new_lines' => isset($args['new_lines']) ? $args['new_lines'] : 'br',
      'default_value' => isset($args['default_value']) ? $args['default_value'] : '',
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'wrapper' => isset($args['wrapper'])?
        $args['wrapper']
        : array(
          'width' => '',
          'class' => '',
          'id' => '',
        ),
    ];
  }






  function acf_repeater( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'Repeater');
    
    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Repeater', $args['name']),
      'name' => $args['name'],
      'type' => 'repeater',
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'conditional_logic' => isset($args['conditional_logic']) ? $args['conditional_logic'] : [],
      'required' => isset($args['required'])? $args['required'] : 0,
      'layout' => isset($args['layout']) ? $args['layout'] : 'table', // table (default) || block || row
      'sub_fields' => isset($args['sub_fields'])? $args['sub_fields'] : [],
    ];
  }




  function acf_action_btns( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'action_btns');
    $id = $args['id'];

    return $this->acf_repeater([
      'id' => $id,
      'name' => $args['name'],
      // 'label' => isset($args['label']) ? $args['label'] : 'Action Buttons',
      'label' => isset($args['label']) ? $args['label'] : 'Кнопки действия',
      'instr' => isset($args['instr']) ? $args['instr'] : '',
      'layout' => 'block',
      'sub_fields' => [
        $this->acf_text([
          'id' => $this->id([$id, 20]),
          'name' => 'href',
          'label' => 'Ссылка кнопки href',
          'instr' => '
            Если нет ссылки и дата-атрибутов укажите "#"<br>
            Если указан дата-атрибут укажите "/"
          ',
          'type' => 'link',
          'required' => 1,
        ]),
        $this->acf_text([
          'id' => $this->id([$id, 30]),
          'name' => 'class',
          'label' => 'CSS class',
        ]),
        $this->acf_text([
          'id' => $this->id([$id, 35]),
          'name' => 'style',
          'label' => 'CSS style',
        ]),
        $this->acf_text([
          'id' => $this->id([$id, 36]),
          'name' => 'data_attr',
          'label' => 'Дата-атрибуты',
          'instr' => $this->data_attrs_use_instr,
        ]),
        $this->acf_checkbox([
          'id' => $this->id([$id, 40]),
          'label' => 'Стиль кнопки',
          'name' => 'attrs',
          // 'layout' => 'vertical',
          'choices' => [
            'block' => 'Во всю ширину',
            'dark' => 'Темный вариант кнопки',
            'light' => 'Светлый вариант кнопки',
            'depressed' => 'Без тени',
            'fab' => 'Круглая кнопка',
            'rounded' => 'Круглые края',
            'x-large' => 'Очень большая кнопка',
            'large' => 'Увеличенная кнопка',
            'small' => 'Уменьшенная кнопка',
            'x-small' => 'Очень маленькая кнопка',
            'outlined' => 'Кнопка-контур',
            'text' => 'Кнопка-текст',
            'primary' => 'Цвет кнопки - основной цвет темы',
          ],
          'default_value' => ['primary'],
        ]),
        $this->acf_rgba_color([
          'id' => $this->id([$id, 50]),
          'name' => 'bgr_color',
          'label' => 'Цвет кнопки',
        ]),
        $this->acf_rgba_color([
          'id' => $this->id([$id, 60]),
          'name' => 'text_color',
          'label' => 'Цвет текста кнопки',
        ]),
      ],
    ]);
  }





  function acf_svg( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'svg');
    
    return $this->acf_textarea([
      'id' => $args['id'],
      'name' => $args['name'],
      'label' => isset($args['label']) ? $args['label'] : 'SVG icon',
      'rows' => 3,
      'instr' => isset($args['instr']) ? $args['instr'] : 'Би&shy;бли&shy;оте&shy;ка иконок: <a href="https://petershaggynoble.github.io/MDI-Sandbox/" target="_blank">Material Design Icons</a> (нужно ско&shy;пи&shy;ро&shy;вать svg код)',
      'required' => isset($args['required'])? $args['required'] : 0,
    ]);
  }





  function acf_icon_name( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'icon_name');

    return $this->acf_textarea([
      'id' => $args['id'],
      'name' => $args['name'],
      'label' => isset($args['label']) ? $args['label'] : 'Имя иконки',
      'rows' => 3,
      'instr' => isset($args['instr'])? $args['required'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
    ]);
  }




  /**
   * @param Array $args['choices'] = [key => val, ...]
   * @param String $args['default_value']
   */
  function acf_radio( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'radio');

    return array(
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Radio', $args['name']),
			'name' => $args['name'],
			'type' => 'radio',
			'instructions' => isset($args['instr'])? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'choices' => isset($args['choices']) ? $args['choices'] : [1 => 'Yes'],
      'layout' => isset($args['layout']) ? $args['layout'] : 'horizontal', // vertical | horizontal
      'default_value' => isset($args['default_value']) ? $args['default_value'] : [],
      'return_format' => isset($args['return_format']) ? $args['return_format'] : 'value', // value | label | array
		);
  }




  function acf_select( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'select');

    return array(
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Select', $args['name']),
			'name' => $args['name'],
			'type' => 'select',
			'instructions' => isset($args['instr'])? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'choices' => isset($args['choices']) ? $args['choices'] : ['Yes' => 'Yes'],
      'layout' => isset($args['layout']) ? $args['layout'] : 'horizontal', // vertical | horizontal
      'default_value' => isset($args['default_value']) ? $args['default_value'] : [],
      'return_format' => isset($args['return_format']) ? $args['return_format'] : 'value', // value | label | array
		);
  }




  /**
   * @param Array $args['choices'] = [key => val, ...]
   * @param Array $args['default_value'] = [key1, key2, ...]
   */
  function acf_checkbox( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'checkbox');

    return array(
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Checkbox', $args['name']),
			'name' => $args['name'],
			'type' => 'checkbox',
			'instructions' => isset($args['instr'])? $args['instr'] : '',
			'required' => isset($args['required'])? $args['required'] : 0,
      'choices' => isset($args['choices']) ? $args['choices'] : [1 => 'Yes'],
      'layout' => isset($args['layout']) ? $args['layout'] : 'horizontal', // vertical | horizontal
      'default_value' => isset($args['default_value']) ? $args['default_value'] : [],
      'return_format' => isset($args['return_format']) ? $args['return_format'] : 'value', // value | label | array
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : 0,
      'layout' => isset($args['layout'])? $args['layout'] : 'horizontal', // vertical | horizontal
		);
  }





  function acf_form_cta( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'form_cta');

    return $this->acf_textarea([
      'id' => $args['id'],
      // 'label' => isset($args['label']) ? $args['label'] : 'Call To Action for main form',
      'label' => isset($args['label']) ? $args['label'] : 'Призыв к действию у формы обратной связи',
      'name' => $args['name'],
      // 'instr' => isset($args['instr']) ? $args['instr'] : 'If it is set, this text will replace form\'s call to action',
      'instr' => isset($args['instr']) ? $args['instr'] : 'Если указано, то используется вместо призыва к действию формы',
      'required' => isset($args['required'])? $args['required'] : 0,
      'rows' => 4,
    ]);
  }





  /* plugin is needed: https://github.com/reyhoun/acf-rgba-color */
  function acf_rgba_color( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'color');
    return $this->acf_color( array_merge($args, ['type' => 'rgba_color']) );
  }


  function acf_color( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'color');

    return [
      'key' => $args['id'],
      'label' => $this->label(isset($args['label']) ? $args['label'] : 'Color picker', $args['name']),
      'name' => $args['name'],
      'type' => isset($args['type']) ? $args['type'] : 'color_picker',
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'default_value' => isset($args['default_value'])? $args['default_value'] : '',
    ];
  }





  function acf_table( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'table');

    return [
			'key' => $args['id'],
			'label' => isset($args['label']) ? $args['label'] : 'Table',
			'name' => $args['name'],
			'type' => 'table',
			'instructions' => isset($args['instr']) ? $args['instr'] : '',
			'required' => isset($args['required']) ? $args['required'] : 0,
			'use_header' => isset($args['header']) ? $args['header'] : 0,
			'use_caption' => isset($args['caption']) ? $args['caption'] : 1,
    ];
  }




  /**
   * @param $args['id']*
   * @param $args['name']*
   * @param $args['label']
   * @param $args['instr']
   * @param $args['min']
   * @param $args['max']
   * @param $args['return_format']
   * @param $args['required']
   * @param $args['related_post_type']*
   *
   */


  /* ADD this to get_all_fields function
    foreach ($this->active_acf as $filed) {
      $acf_name = $filed['name'];

      if ($acf_name == $this->acf->related_form) {
        $x = get_field($acf_name, $post_id);
        $o->{$acf_name} = __rest_get_post_with_acf([
          'default_post_id' => is_array($x)? $x[0] : '',
          'get_only_acf' => true,
          'my_acf_alias' => FORMS_ALIAS,
          'acf_in_acf_key' => false,
        ], $lang);
      }
  */
  function acf_post_relation( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'related_posts');

    return [
      'key' =>  $args['id'],
      'name' => $args['name'],
      'label' =>  $this->label((isset($args['label']) ? $args['label'] : 'Связанная со страницей форма'), $args['name']),
      'type' => 'relationship',
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'return_format' => isset($args['return_format'])? $args['return_format'] : 'object', // object | id
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
      'post_type' => isset($args['post_type']) ? $args['post_type'] : [
        0 => isset($args['related_post_type']) ? $args['related_post_type'] : trigger_error('args[related_post_type] is not defined!', E_USER_ERROR),
      ],
      'taxonomy' => '',
      'filters' => [
        0 => 'search',
        1 => 'taxonomy',
      ],
      'elements' => '',
      'min' => isset($args['min']) ? $args['min'] : '',
      'max' => isset($args['max']) ? $args['max'] : '',
    ];
  }





  function acf_taxonomy_relation( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'related_taxonomies');

    return [
      'key' =>  $args['id'],
      'name' => $args['name'],
      'label' =>  $this->label((isset($args['label']) ? $args['label'] : 'Связанная со страницей форма'), $args['name']),
      'type' => 'taxonomy',
      'instructions' => isset($args['instr']) ? $args['instr'] : '',
      'required' => isset($args['required'])? $args['required'] : 0,
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
      'field_type' => isset($args['field_type']) ? $args['field_type'] : 'multi_select', // checkbox | multi_select | radio | select
      /* (bool) Allow a null (blank) value to be selected. Defaults to 0 */
      'allow_null' => isset($args['allow_null']) ? $args['allow_null'] : 0,
      /* (bool) Allow selected terms to be saved as relatinoships to the post */
      'load_save_terms' => isset($args['load_save_terms']) ? $args['load_save_terms'] : 0,
      /* (string) Specify the taxonomy to select terms from. Defaults to 'category' */
      'taxonomy' => isset($args['taxonomy'])? $args['taxonomy'] : 'category',
      /* (bool) Allow new terms to be added via a popup window */
      'add_term' => isset($args['add_term'])? $args['add_term'] : 0, // {Boolean}
      'return_format' => isset($args['return_format'])? $args['return_format'] : 'object', // object | id
    ];
  }










  /**
   * @param $args['id']*
   * @param $args['name']
   * @param $args['extra_fields']
   * @param $args['static_form_label'] default = 'Статичная'
   * @param Boolean $args['static_form'] default = true
   * @param $args['changing_form_label'] default = 'Динамичная'
   * @param Boolean $args['changing_form'] default = true
   * @param Boolean $args['related_form'] default = true
   */
  function acf_form_set( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'form');
    $id = $args['id'] . '_';

    $this->form_type_id = $id .'_fе_';
    $this->form_type_key = $this->uniqueKey( $this->form_type_id );

    $args['static_form'] = isset($args['static_form'])? $args['static_form'] : true;
    $args['changing_form'] = isset($args['changing_form'])? $args['changing_form'] : true;
    $args['related_form'] = isset($args['related_form'])? $args['related_form'] : true;
    $args['changing_form_label'] = isset($args['changing_form_label'])? $args['changing_form_label'] : 'Динамичная';
    $args['static_form_label'] = isset($args['static_form_label'])? $args['static_form_label'] : 'Статичная';

    $args['extra_fields'] = isset($args['extra_fields'])? $args['extra_fields'] : [
      $this->acf_image([
        'id' =>  $this->id([$id, 50]),
        'label' => 'Картинка к форме',
      ]),
      $this->acf_class_style_text([
        'id' =>  $this->id([$id, 100]),
        'name' => 'form_cta',
        'label' => 'Текст призыва к действию',
      ]),
      $this->acf_class_style_text([
        'id' =>  $this->id([$id, 200]),
        'label' => 'Заголовок формы',
        'name' => 'title',
        'rows' => 3,
      ]),
      $this->acf_class_style_text([
        'id' =>  $this->id([$id, 300]),
        'label' => 'Подзаголовок формы',
        'name' => 'subtitle',
        'rows' => 3,
      ]),
      $this->acf_text([
        'id' =>  $this->id([$id, 400]),
        'label' => 'Текст кнопки "отправить форму"',
        'name' => 'submit_btn_text',
        'default_value' => 'Отправить',
      ]),
    ];

    $choices = [];
    if ($args['related_form']) $choices['existing'] = $this->label('Типовая', 'existing');
    if ($args['static_form']) $choices['static_form'] = $this->label( $args['static_form_label'], 'static_form' );
    if ($args['changing_form']) $choices['changing_form'] = $this->label( $args['changing_form_label'], 'changing_form' );


    return $this->acf_group([
      "id" => $id,
      "name" => "form",
      "label" => "<h1>Форма обратной связи</h1>",
      "layout" => "block",
      "sub_fields" => array_merge( $args['extra_fields'], [

          $this->acf_radio([
            'id' => $this->form_type_id,
            'label' => 'Какую форму использовать?',
            'name' => 'form_type',
            'choices' => $choices,
            // 'choices' => [
            //   'existing' => $this->label('Типовая', 'existing'),
            //   'static_form' => $this->label('Уникальная статичная форма', 'static_form'),
            //   'changing_form' => $this->label('Уникальная Динамичная форма', 'changing_form'),
            // ],
            'default_value' => 'existing'
          ]),

          /******* RELATED *******/
          $this->acf_post_relation([
            'id' =>  $this->id([$id, 300]),
            'name' => 'related_form',
            'conditional_logic' => [
              array(
                [
                  'field' => $this->form_type_key,
                  'operator' => '==',
                  'value' => 'existing',
                ],
              ),
            ],
            'max' => 1,
            'related_post_type' => MY_CPT_FORMS,
          ]),

          /******* STATIC *******/
          $this->acf_custom_form([
            'conditional_logic' => [
              array(
                [
                  'field' => $this->form_type_key,
                  'operator' => '==',
                  'value' => 'static_form',
                ],
              ),
            ],
            'id' => $this->id([$id, 400]),
          ]),
        ], /******* CHANGIN *******/
        $this->acf_custom_changing_form([
          'conditional_logic' => [
            array(
              [
                'field' => $this->form_type_key,
                'operator' => '==',
                'value' => 'changing_form',
              ],
            ),
          ],
          'id' => $this->id([$id, 500]),
        ])
      ), // array_merge && sub_fields

    ]);
  }





  function acf_set_styles_by_link( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'embedded_styles');
    $id = $args['id'];

    return $this->acf_group([
      'id' => $this->id([$id, 10]),
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Встроенные стили',
      'layout' => 'block',
      'sub_fields' => [
        // $this->acf_text([
        //   'id' =>  $this->id([$id, 10, 10]),
        //   'name' => 'start_timetable_hour',
        //   'label' => 'Расписание рассматривается с чч:мм',
        // ]),
        $this->acf_repeater([
          'id' =>  $this->id([$id, 10, 20]),
          'name' => 'styles',
          'label' => isset($args['label'])? $args['label'] : 'Стили',
          'layout' => isset($args['layout'])? $args['layout'] : 'row',
          'required' => isset($args['required'])? $args['required'] : 0,
          'sub_fields' => [
            /*** INPUT ACF ***/
            $this->acf_text([
              'id' =>  $this->id([$id, 10, 20, 10]),
              'name' => 'src',
              'label' => 'Ссылка (src)',
              'required' => 1,
            ]),
            $this->acf_textarea([
              'id' =>  $this->id([$id, 10, 20, 20]),
              'name' => 'css',
              'label' => 'CSS стиль',
              'required' => 1,
              'rows' => 10,
            ]),
          ],
        ])
      ],
    ]);
  }





  function acf_timetable( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'timetable');
    $id = $args['id'];

    return $this->acf_group([
      'id' => $this->id([$id, 10]),
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Расписание',
      'layout' => 'block',
      'sub_fields' => [
        $this->acf_date_time([
          'id' =>  $this->id([$id, 10, 10]),
          'name' => 'start_timetable_hour',
          'type' => 'time_picker',
          'label' => 'Расписание рассматривается с чч:мм',
          'return_format' => 'H:i',
        ]),
        $this->acf_repeater([
          'id' =>  $this->id([$id, 10, 20]),
          'name' => 'events',
          'label' => isset($args['label'])? $args['label'] : 'Расписание',
          'layout' => isset($args['layout'])? $args['layout'] : 'row',
          'required' => isset($args['required'])? $args['required'] : 0,
          'sub_fields' => [
            /*** INPUT ACF ***/
            $this->acf_text([
              'id' =>  $this->id([$id, 10, 20, 10]),
              'name' => 'name',
              'label' => 'Название',
              'required' => 1,
            ]),
            $this->acf_date_time([
              'id' =>  $this->id([$id, 10, 20, 20]),
              'name' => 'start',
              'label' => 'Начало',
              'required' => 1,
              'return_format' => 'Y-m-d H:i',
            ]),
            $this->acf_date_time([
              'id' =>  $this->id([$id, 10, 20, 30]),
              'name' => 'end',
              'label' => 'Конец',
              'required' => 1,
              'return_format' => 'Y-m-d H:i',
            ]),
            $this->acf_color([
              'id' =>  $this->id([$id, 10, 20, 40]),
              'name' => 'color',
              'label' => 'Цвет события',
              'default_value' => '#fff',
            ]),
            $this->acf_color([
              'id' =>  $this->id([$id, 10, 20, 50]),
              'name' => 'textColor',
              'label' => 'Цвет текста',
              'default_value' => '#000',
            ]),
            $this->acf_textarea([
              'id' =>  $this->id([$id, 10, 20, 60]),
              'name' => 'details',
              'label' => 'Описание события',
              'rows' => 4,
            ]),
          ],
        ])
      ],
    ]);
  }




  function acf_custom_changing_form( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, '');
    $id = $args['id'];

    return [
      $this->acf_group([
        'id' => $this->id([$id, 10]),
        'name' => 'condition_input',
        'label' => 'Поле ввода, меняющее форму',
        'layout' => 'row',
        'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
        'sub_fields' => [
          $this->acf_radio([
            'id' =>  $this->id([$id, 10, 5]),
            'name' => 'input_type',
            'label' => 'Тип поля',
            'choices' => [
              'radio' => 'Radio (Можно выбрать только 1 знач.)',
              'select' => 'Выпадающий список',
            ],
            'default_value' => 'select'
          ]),
          $this->acf_text([
            'id' =>  $this->id([$id, 10, 6]),
            'name' => 'label',
            'label' => 'Имя поля',
            'default_value' => 'Выбрать тип формы'
          ]),
          $this->acf_repeater([
            'id' =>  $this->id([$id, 10, 10]),
            'name' => 'selection_form_items',
            'label' => 'Варианты ответов',
            'required' => 1,
            'sub_fields' => [
              /** Варианты ответов **/
              $this->acf_text([
                'id' => $this->id([$id, 10, 10, 5]),
                'name' => 'id',
                'label' => 'ID',
                'instr' => 'Должны быть уникальными',
                'type' => 'number',
                'required' => 1,
                'default_value' => 1,
              ]),
              $this->acf_text([
                'id' => $this->id([$id, 10, 10, 10]),
                'name' => 'value',
                'label' => 'Варианты',
                'required' => 1,
              ]),
              $this->acf_true_false([
                'id' => $this->id([$id, 10, 10, 20]),
                'name' => 'selected',
                'label' => 'Изначально выбрано',
                'message' => '',
                'default_value' => 0,
              ]),
            ],
          ]), // acf_repeater
          $this->acf_class_style_block([
            'id' => $this->id([$id, 10, 20]),
          ]),
        ], // sub_fields
      ]),
      
      $this->acf_repeater([
        'id' => $this->id([$id, 20]),
        'name' => 'custom_changing_form',
        'label' => 'Динамичная форма',
        'layout' => 'row',
        'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
        'sub_fields' => [
          $this->acf_text([
            'id' => $this->id([$id, 20, 10]),
            'name' => 'condition_input_v_id',
            'label' => 'ID поля меняющего форму',
            'type' => 'number',
            'instr' => 'ID берется отсюда: Поле ввода, меняющее форму -> Варианты ответов -> ID -> Конкретное ID'
          ]),
          $this->acf_custom_form([
            'id' => $this->id([$id, 20, 20]),
          ]),
        ],
      ]),
    ];
  }




  function acf_custom_form( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'custom_static_form');
    $id = 'aff_' . $args['id'];
    $this->input_type_id = $id .'_f_';
    $this->input_type_key = $this->uniqueKey( $this->input_type_id );

    return $this->acf_repeater([
      'id' =>  $this->id( [$id] ),
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Уникальная форма',
      'layout' => isset($args['layout'])? $args['layout'] : 'row',
      'instr' => isset($args['instr'])? $args['instr'] : 'Добавьте новые желанные поля для формы',
      'conditional_logic' => isset($args['conditional_logic'])? $args['conditional_logic'] : [],
      'required' => isset($args['required'])? $args['required'] : 0,
      'sub_fields' => [

        /*** INPUT ACF ***/
        $this->acf_text([
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'condition_input',
              ],
            ),
          ],
          'id' =>  $this->id([$id, 10]),
          'name' => 'label',
          'label' => 'Имя поля',
        ]),

        $this->acf_true_false([
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'condition_input',
              ],
            ),
          ],
          'id' =>  $this->id([$id, 20]),
          'name' => 'required',
          'label' => " ",
          'message' => 'Обязательное поле',
        ]),

        $this->acf_radio([
          'id' => $this->input_type_id,
          'name' => 'input_type',
          'label' => 'Тип поля',
          'choices' => [
            'checkbox' => 'Checkbox (поле с галочой)',
            'radio' => 'Radio (Можно выбрать только 1 знач.)',
            'textfield' => 'Текстовая строка',
            'textarea' => 'Текстовое поле',
            'select' => 'Выпадающий список',
            'file' => 'Файл',
            'comment' => 'Текст/Пояснения/Комментарии',
            'condition_input' => 'Поле, меняющее форму (толкьо если выбрана Динамичная форма)',
          ],
          'default_value' => 'textfield'
        ]),

        $this->acf_message([
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'condition_input',
              ],
            ),
          ],
          'id' =>  $this->id([$id, 11]),
          'label' => 'Пояснение',
          'message' => 'На месте этого поля появится поле, меняющее форму.
            Если, форма статичная (не Динамичная), то это поле проигнорируется.
          ',
        ]),

        $this->acf_checkbox([
          'id' => $this->id([$id, 200]),
          'name' => 'options',
          'label' => 'Опции',
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'select',
              ],
            ),
          ],
          'choices' => [
            'multiple' => 'Множественный выбор',
            'clearable' => 'Иконка "Стереть"',
          ],
          'default_value' => [],
        ]),

        /* TEXTFIELD */
        $this->acf_group([
          'id' =>  $this->id([$id, 300]),
          "name" => "textfield",
          "label" => "Настройка поля ввода",
          "layout" => "table",
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'textfield',
              ],
            ),
          ],
          "sub_fields" => [
            $this->acf_text([
              'id' =>  $this->id([$id, 300, 10]),
              'name' => 'placeholder',
              'label' => 'Placeholder',
            ]),
            $this->acf_text([
              'id' =>  $this->id([$id, 300, 20]),
              'name' => 'value',
              'label' => 'Начальное значение',
            ]),
          ]
        ]),



        /* TEXTAREA */
        $this->acf_group([
          'id' =>  $this->id([$id, 400]),
          "name" => "textarea",
          "label" => "Настройка поля ввода",
          "layout" => "table",
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'textarea',
              ],
            ),
          ],
          "sub_fields" => [
            $this->acf_text([
              'id' =>  $this->id([$id, 400, 10]),
              'name' => 'placeholder',
              'label' => 'Placeholder',
            ]),
            $this->acf_text([
              'id' =>  $this->id([$id, 400, 20]),
              'name' => 'value',
              'label' => 'Начальное значение',
            ]),
          ]
        ]),



        /* FILE */
        $this->acf_group([
          'id' =>  $this->id([$id, 450]),
          "name" => "file",
          "label" => "Настройка поля ввода",
          "layout" => "rows",
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'file',
              ],
            ),
          ],
          "sub_fields" => [
            $this->acf_textarea([
              'id' =>  $this->id([$id, 450, 10]),
              'name' => 'file_types',
              'label' => 'Разрешенные форматы',
              'instr' => 'Если пусто, то разрешены любые форматы',
              'rows' => 3,
            ]),
            $this->acf_checkbox([
              'id' => $this->id([$id, 450, 20]),
              'name' => 'options',
              'label' => 'Опции',
              'choices' => [
                'multiple' => 'Можно прикрепить > 1 файла',
              ],
              'default_value' => [],
            ]),
            // $this->acf_rgba_color([
            //   'id' => $this->id([$id, 450, 30]),
            //   'name' => 'btn_bgr_color',
            //   'label' => 'Цвет кнопки',
            // ]),
            // $this->acf_rgba_color([
            //   'id' => $this->id([$id, 450, 40]),
            //   'name' => 'btn_text_color',
            //   'label' => 'Цвет текста кнопки',
            // ]),
          ]
        ]),
        
        /* SELECT */ /* RADIO and CHECKBOX */
        $this->acf_repeater([
          'id' =>  $this->id([$id, 600]),
          'name' => 'selection_items',
          'label' => 'Варианты ответов',
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'select',
              ],
            ),
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'radio',
              ],
            ),
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'checkbox',
              ],
            ),
          ],
          'required' => 1,
          'sub_fields' => [
            /** Варианты ответов **/
            $this->acf_text([
              'id' =>  $this->id([$id, 600, 10]),
              'name' => 'value',
              'label' => 'Варианты',
              'required' => 1,
              'rows' => 2,
            ]),
            $this->acf_true_false([
              'id' =>  $this->id([$id, 600, 20]),
              'name' => 'selected',
              'label' => 'Изначально выбрано',
              'message' => '',
              'default_value' => 0,
            ]),
          ],
        ]),

        /* COMMENT */
        $this->acf_group([
          'id' =>  $this->id([$id, 700]),
          "name" => "comment",
          "label" => "Текст/Пояснения/Комментарии",
          "layout" => "block",
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '==',
                'value' => 'comment',
              ],
            ),
          ],
          "sub_fields" => [
            $this->acf_class_style_text([
              'id' =>  $this->id([$id, 700, 10]),
              'name' => 'comment',
              'label' => 'Текст',
              'rows' => 4,
            ]),
            // $this->acf_text([
            //   'id' =>  $this->id([$id, 400, 20]),
            //   'name' => 'value',
            //   'label' => 'Начальное значение',
            // ]),
          ]
        ]),

        /* HINT */
        $this->acf_group([
          'id' =>  $this->id([$id, 800]),
          "name" => "hint",
          "label" => "Пояснение к полю",
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'comment',
              ],
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'radio',
              ],
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'checkbox',
              ],
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'condition_input',
              ],
            ),
          ],
          "layout" => "table",
          "sub_fields" => [
            $this->acf_textarea([
              'id' =>  $this->id([$id, 800, 10]),
              'name' => 'text',
              'label' => 'Текст',
              'rows' => 3,
            ]),
            $this->acf_checkbox([
              'id' =>  $this->id([$id, 800, 20]),
              'name' => 'options',
              'label' => 'Тип поля',
              'choices' => [
                'persistent' => 'Пояснение всегда видно',
              ],
              'default_value' => ['persistent'],
            ]),
          ]
        ]),

        $this->acf_class_style_block([
          'conditional_logic' => [
            array(
              [
                'field' => $this->input_type_key,
                'operator' => '!=',
                'value' => 'condition_input',
              ],
            ),
          ],
          'id' =>  $this->id([$id, 900]),
        ]),

      ] // sub_fields
    ]);
  }







  function acf_gif_video_img_gallery_set( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'gallery');
    $id = 'gvigs_' . $args['id'];
    $this->set_type_id = $id .'_f_';
    $this->set_type_key = $this->uniqueKey( $this->set_type_id );

    $this->video_type_id = $this->id([$id, 300, 50]);
    $this->video_type_key = $this->uniqueKey( $this->video_type_id );

    return $this->acf_repeater([
      'id' =>  $this->id( [$id] ),
      'name' => $args['name'],
      'label' => isset($args['label'])? $args['label'] : 'Галерея',
      'layout' => isset($args['layout'])? $args['layout'] : 'row',
      'required' => isset($args['required'])? $args['required'] : 1,
      'sub_fields' => [

        /* OPTIONS */
        $this->acf_radio([
          'id' => $this->set_type_id,
          'name' => 'type',
          'label' => 'Тип поля',
          'choices' => [
            'image' => $this->label('Изображение/GIF', 'image'),
            'video' => $this->label('Видео', 'video'),
          ],
          'default_value' => 'image'
        ]),

        /* Image/GIF */
        $this->acf_image([
          'conditional_logic' => [
            array([
              'field' => $this->set_type_key,
              'operator' => '==',
              'value' => 'image',
            ]),
          ],
          'id' => $this->id([$id, 200]),
        ]),


        /* VIDEO */
        $this->acf_group([
          'conditional_logic' => [
            array([
              'field' => $this->set_type_key,
              'operator' => '==',
              'value' => 'video',
            ]),
          ],
          'id' =>  $this->id([$id, 300]),
          "name" => "video",
          "label" => "Видео",
          "layout" => "block",
          "sub_fields" => [
            $this->acf_radio([
              'id' =>  $this->video_type_id,
              'name' => 'type',
              'label' => 'Тип видео',
              'choices' => [
                'youtube' => $this->label('youtube', 'youtube'),
              ],
              'default_value' => "youtube",
            ]),
            $this->acf_message([
              'conditional_logic' => [
                array([
                  'field' => $this->video_type_key,
                  'operator' => '==',
                  'value' => 'youtube',
                ]),
              ],
              'id' => $this->id([$id, 300, 'urlmsg', 10]),
              'message' => 'Указывайте ссылку в формате "<b>https://www.youtube.com/watch?v=<span style="color:blue">i3TQQCxRxZk</span></b>"
                или просто id видео "<b><span style="color:blue">i3TQQCxRxZk</span></b>"
              ',
            ]),
            $this->acf_text([
              'id' =>  $this->id([$id, 300, 100]),
              'name' => 'url',
              'label' => 'Ссылка',
              'required' => 1,
            ]),
            // $this->acf_checkbox([
            //   'id' =>  $this->id([$id, 300, 200]),
            //   'name' => 'options',
            //   'label' => 'Опции',
            //   'choices' => [
            //     // 'youtube' => 'youtube',
            //     'video_avatar' => 'Заставка к видео',
            //   ],
            //   'default_value' => ['video_avatar'],
            // ]),
          ], // video sub_fields
        ]),

        $this->acf_class_style_text([
          'id' => $this->id([$id, 400]),
          'name' => 'description',
          'label' => 'Описание',
          'rows' => 2,
        ]),

      ] // sub_fields
    ]);
  } // acf_gif_video_img_gallery_set





  function acf_hero_section_img( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'hero_section_img');
    $id = $args['id'];

    return $this->acf_group([
      "id" => $id,
      "name" => $args['name'],
      "label" => isset($args['label'])? $args['label'] : "<h1>Глав&shy;ное изо&shy;бра&shy;же&shy;ние на стра&shy;ни&shy;це</h1>",
      "layout" => isset($args['layout'])? $args['layout'] : "row",
      "instr" => isset($args['instr'])? $args['instr'] : "",
      "sub_fields" => [
        $this->acf_image([
          "id" => $this->id($id, 10),
          "name" => "img",
          "label" => "Изо&shy;бра&shy;же&shy;ние",
          "preview_size" => "medium_large"
          // "required" => 1,
        ]),
        $this->acf_text([
          "id" => $this->id($id, 20),
          'label' => 'Минимальная высота изображения блока с изо&shy;бра&shy;же&shy;нием (px)',
          'type' => 'number',
          'name' => 'height',
          'default_value' => '360',
          'required' => 1,
        ]),
        $this->acf_rgba_color([
          "id" => $this->id($id, 30),
          'name' => 'bgr_color',
          'label' => 'Цвет фона',
          'instr' => 'Показывается если иображение не задано',
        ]),
      ],
    ]);
  } // acf_hero_section_img




  function acf_archive_card( $id_or_args=[], $args=[] ) {
    $args = $this->get_args( $id_or_args, $args, 'hero_section_img');
    $id = $args['id'];

    $lmbt = isset($args['learn_more_btn_text'])? $args['learn_more_btn_text'] : true;
    $lmbt = $lmbt? [$this->acf_learm_more_btn_text( $this->id($id, 'lm') )] : [];

    $sub_fields = isset($args['sub_fields'])? $args['sub_fields'] : [];

    return $this->acf_group([
      "id" => $this->id($id, 10),
      "name" => "archive_card",
      "label" => "<h1>Отбражение поста в списке постов</h1>",
      "layout" => "row",
      "sub_fields" => array_merge([
        $this->acf_image([
          'id' => $this->id($id, 10, 100),
          "name" => "avatar",
          "label" => "Аватарка поста",
          "instr" => 'Оптимальные размеры: 900х600',
          // "required" => 1,
        ]),
        $this->acf_class_style_text([
          'id' => $this->id($id, 10, 300),
          'label' => 'Краткое описание поста',
          'name' => 'description',
          "instr" => 'Если не указано, то используется подзаголовок мероприятия (призвы к действию)',
          'row' => 4,
        ]),
      ], $lmbt, $sub_fields
      )
    ]);
  }






















  /**
   * @param boolean $args['post_id_is_required']
   * @param int $args['post_id']
   * @param string $args['option_name']
   */
  function get_all_simple_fields( $args=[] ) {
    isset($args['post_id_is_required']) ? $post_id_is_required = 1 : $post_id_is_required = 0;

    # post_id is required
    if ($post_id_is_required) {
      if (!isset($args['post_id'])) trigger_error('$args["post_id"] is not defined!', E_USER_ERROR);
      $post_id = $args['post_id'];

    # post_id is NOT required
    } else {

      if (isset($args['post_id'])) {
        $post_id = $args['post_id'];
      }
      
      else {
        if (isset($args['option_name'])) {
          $post_id = get_option( $args['option_name'] );
        } else {
          trigger_error('You must define $args["post_id"] OR $args["option_name"] !', E_USER_ERROR);
        }
      }
    }

    $o = (object) [];

    foreach ($this->active_acf as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    return $o;
  }


  function get_all_acf_simple_fields($o=[], $_active_acf_) {
    foreach ($_active_acf_ as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    return $o;
  }


}