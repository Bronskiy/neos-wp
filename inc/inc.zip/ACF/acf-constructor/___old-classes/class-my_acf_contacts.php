<?php

class MY_ACF_Contacts extends MY_ACF {

  public $acf_group_key = MY_CPT_SETTINGS . 'cont_' . '_acf_group_key';

  public $post_type = MY_CPT_SETTINGS;

  public $active_acf;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'cont_';

  public function register() {
    $this->acf = (object) [];

    $this->active_acf = [

      $this->acf_repeater([
        'id' => 100,
        'name' => 'emails',
        'label' => 'Настройка почты',
        'sub_fields' => [
          $this->acf_icon_name( $this->id(100, 10) ),
          $this->acf_text([
            'id' => $this->id(100, 30),
            'name' => 'email',
            'label' => 'Email',
            'required' => 1,
          ]),
          $this->acf_line_desc( $this->id(100, 40) )
        ],
      ]),

      $this->acf_repeater([
        'id' => 200,
        'name' => 'telephones',
        'label' => 'Настройка телефонов',
        'sub_fields' => [
          $this->acf_icon_name( $this->id(200, 10) ),
          $this->acf_text([
            'id' => $this->id(200, 30),
            'name' => 'tel',
            'label' => 'Телефон',
            'required' => 1,
          ]),
          $this->acf_line_desc( $this->id(200, 40) )
        ],
      ]),

      $this->acf_repeater([
        'id' =>  $this->id( 50 ),
        'name' => 'info_list',
        'label' => 'Колонки с контактами',
        'layout' => 'row',
        'sub_fields' => [
          $this->acf_flexible_content([
            'id' => $this->id( 50, 1 ),
            'name' => 'column',
            'label' => 'Колонка с контактами',
            'layouts' => [
              array(
                'key' => 'layout_' . $this->uniqueKey( $this->id( 50, 1, 100 ) ),
                'name' => 'string',
                'label' => 'Строку',
                'display' => 'block',
                'sub_fields' => [
                  $this->acf_text([
                    'id' => $this->id( 50, 1, 100, 10 ),
                    'name' => 'string',
                    'label' => 'Строка',
                  ]),
                ],
              ),
              array(
                'key' => 'layout_' . $this->uniqueKey( $this->id( 50, 1, 200 ) ),
                'name' => 'action_string',
                'label' => 'Строку с ссылкой',
                'display' => 'table',
                'sub_fields' => array(
                  $this->acf_text([
                    'id' => $this->id( 50, 1, 200, 10 ),
                    'name' => 'prefix',
                    'label' => 'Префикс',
                  ]),
                  $this->acf_text([
                    'id' => $this->id( 50, 1, 200, 20 ),
                    'name' => 'content',
                    'label' => 'Контент',
                  ]),
                  $this->acf_text([
                    'id' => $this->id( 50, 1, 200, 30 ),
                    'name' => 'postfix',
                    'label' => 'Постфикс',
                  ]),
                  $this->acf_select([
                    'id' => $this->id( 50, 1, 200, 40 ),
                    'name' => 'role',
                    'label' => 'Роль',
                    'choices' => [
                      'Email' => 'Email',
                      'tel' => 'Телефон',
                      'vk' => 'vk',
                      'facebook' => 'facebook',
                      'map' => 'карта',
                    ],
                  ]),
                ),
              ),
            ],
          ]),
        ],
      ]),

      // $this->acf_repeater([
      //   'id' => 300,
      //   'name' => 'addresses',
      //   'label' => 'Настройка адресов',
      //   'layout' => 'row',
      //   'sub_fields' => array_merge(
      //     $this->acf_map([
      //       'id' => $this->id([300, 10]),
      //       'image' => true,
      //     ]), [ /* extra acf fields */ ]
      //   ),
      // ]),

      // $this->acf_repeater([
      //   'id' => 400,
      //   'name' => 'working_hours',
      //   // 'label' => 'Working hours settings',
      //   'label' => 'Настройка времени работы',
      //   'sub_fields' => [
      //     $this->acf_text([
      //       'id' => $this->id(400, 20),
      //       'name' => 'working_hours',
      //       'label' => 'Working hours',
      //       'required' => 1,
      //     ]),
      //     $this->acf_line_desc( $this->id(400, 30) )
      //   ],
      // ]),

      // $this->acf_repeater([
      //   'id' => 500,
      //   'name' => 'requisites',
      //   'label' => 'Настройка реквизитов',
      //   'sub_fields' => [
      //     $this->acf_text([
      //       'id' => $this->id(500, 10),
      //       'name' => 'requisite',
      //       'label' => 'Requisite',
      //       'required' => 1,
      //     ]),
      //   ],
      // ]),

      // $this->acf_repeater([
      //   'id' => 600,
      //   'name' => 'social_networks',
      //   'label' => 'Настройка соцсетей',
      //   'sub_fields' => [
      //     $this->acf_icon_name( $this->id(600, 5) ),
      //     $this->acf_text([
      //       'id' => $this->id(600, 20),
      //       'name' => 'social_network',
      //       'label' => 'Link',
      //       'type' => 'link',
      //       'required' => 1,
      //     ]),
      //     // $this->acf_line_desc( $this->id(600, 30) ),
      //   ]
      // ]),
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }





  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ){
      acf_add_local_field_group( array(
        'key' => $this->acf_group_key,
        'title' => 'Контакты',
        'fields' => $this->active_acf,
        'location' => [
          array(
            array(
              'param' => 'post_type',
              'operator' => '==',
              'value' => MY_CPT_SETTINGS,
            ),
            array(
              'param' => 'page',
              'operator' => '==',
              'value' => get_option( '__contacts_post_id__' ),
            ),
          ),
        ],
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
      ));
    }
  }





















  public function get_all_fields($post_id='') {
    if (__ACF_DEBUG__) echo " ___acf_contacts___ <br>\n";
    return $this->get_all_simple_fields([
      'post_id' => $post_id,
      'option_name' => '__contacts_post_id__',
    ]);
  }



  
}