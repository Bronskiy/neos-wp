<?php

class MY_ACF_FORMS extends MY_ACF {

  public $acf_group_key = MY_CPT_FORMS . '_acf_group_key';

  public $post_type = MY_CPT_FORMS;

  public $active_acf;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'forms_';

  public function register() {
    $this->acf = (object) [];
    $id = '_ft_';
    $this->form_type_id = $id .'_fе_';
    $this->form_type_key = $this->uniqueKey( $this->form_type_id );
    $this->changin_f_id = '_cf_';

    $this->active_acf = [
      $this->acf_form_set([
        'id' => $this->id([ 100 ]),
        'related_form' => true,
      ]),
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }






  public function acf_init() {

    if( function_exists('acf_add_local_field_group') ) {
      acf_add_local_field_group([
        'key' => $this->acf_group_key,
        'title' => 'Настройки формы',
        'fields' => $this->active_acf,
        'location' => [
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => $this->post_type,
            ],
          ),
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => MY_CPT_S_SETTINGS,
            ],
            [
              'param' => 'page',
              'operator' => '==',
              'value' => get_option('__order_main_form_post_id__'),
            ],
          ),
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => MY_CPT_S_SETTINGS,
            ],
            [
              'param' => 'page',
              'operator' => '==',
              'value' => get_option('__order_call_form_post_id__'),
            ],
          ),
        ],
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
      ]);
      
    };
  }






  public function get_all_fields($post_id) {
    if (__ACF_DEBUG__) echo " ___acf_forms___ <br>\n";
    return $this->get_all_simple_fields([
      'post_id' => $post_id,
      'post_id_is_required' => 1,
    ]);
  }


}