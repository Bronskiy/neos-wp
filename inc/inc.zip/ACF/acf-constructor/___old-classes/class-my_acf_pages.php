<?php

class MY_ACF_Pages extends MY_ACF {

  public $acf_group_key = 'my_pages_acf_group_key';

  public $post_type = 'page';

  public $active_acf_1; /* Контент */
  public $active_acf_2; /* Карточка услуги в архиве */
  public $active_acf_3; /* Форма */

  public $location;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $unique_id_prefix = 'pages_';

  public function register() {
    $this->acf = (object) [];

    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => 'page',
        ],
        [
          'param' => 'page',
          'operator' => '!=',
          'value' => get_option('__about_us_post_id__'),
        ],
        [
          'param' => 'page',
          'operator' => '!=',
          'value' => get_option(__PRIVACY_POLICY_ID__),
        ],
      ),
    ];


    $this->active_acf_1 = [
      $this->acf_hero_section_img([
        "id" => $this->id(50),
        "name" => "main_img",
      ]),
      $this->acf_page_title( 100 ),
      $this->acf_page_subtitle([
        'id' => 200,
      ]),
      $this->acf_text([
        'id' => 250,
        'name' => 'breadcrumb_title',
        'label' => 'Заголовок в хлебных крошках',
      ]),
      $this->acf_action_btns([
        'id' => 300,
        'label' => 'Hero-section action buttons',
      ]),
      $this->acf_textarea([
        'id' => 600,
        'name' => 'menu_icon_name',
        'label' => 'Menu icon name',
        'rows' => 3,
        'instructions' => 'Имя икон&shy;ки бе&shy;рет&shy;ся <a href="https://petershaggynoble.github.io/MDI-Sandbox/" target="_blank">здесь</a>'
      ]),
    ];

    // /* Карточка услуги в архиве */
    // $this->active_acf_2 = [
    //   $this->acf_order([
    //     'id' => $this->id('aa6', 5),
    //   ]),
    // ];

    /* Форма */
    $this->active_acf_3 = [
      $this->acf_form_set([
        'id' => $this->id('aa3', 100 ),
        'static_form_label' => 'Уникальная статичная форма',
        'changing_form_label' => 'Уникальная динамичная форма',
      ]),
    ];
  
    add_action( 'acf/init', [$this, 'acf_init'] );
  }















  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => 'Контент страницы',
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      
      // $this->register_acf_group([
      //   'title' => 'Карточка услуги в архиве',
      //   'group_key' => $this->acf_group_key.'2',
      //   'fields' => $this->active_acf_2,
      //   'location' => $this->location,
      // ]);

      $this->register_acf_group([
        'title' => 'Форма',
        'group_key' => $this->acf_group_key.'3',
        'fields' => $this->active_acf_3,
        'location' => $this->location,
      ]);
    };
  }












  













  public function get_all_fields($post_id, $lang='') {
    if (__ACF_DEBUG__) echo " ___acf_pages___ <br>\n";
    global $my_acf;
    $o = (object) [];


    /*** THIS ***/
    foreach ($this->active_acf_1 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    // foreach ($this->active_acf_2 as $filed) {
    //   $acf_name = $filed['name'];
    //   $o->{$acf_name} = get_field($acf_name, $post_id);
    // }
    foreach ($this->active_acf_3 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }


    /*** SEO ***/
    $seo = (object) [];
    $seo->{SEO_ALIAS} = __rest_get_post_with_acf([
      'default_post_id' => $post_id,
      'get_only_acf' => true,
      'my_acf_alias' => SEO_ALIAS,
      'acf_in_acf_key' => false,
    ], $lang);

    /*** front_page ***/
    $front_page = (object) __rest_get_post_with_acf([
      'default_post_id' => $post_id,
      'get_only_acf' => true,
      'my_acf_alias' => 'front_page',
      'acf_in_acf_key' => false,
    ], $lang);

    /*** EVENTS ***/
    // $events = (object) __rest_get_post_with_acf([
    //   'default_post_id' => $post_id,
    //   'get_only_acf' => true,
    //   'my_acf_alias' => EVENTS_ALIAS,
    //   'acf_in_acf_key' => false,
    // ], $lang);

    $o = (object) array_merge(
      (array) $o,
      (array) $seo,
      (array) $front_page
      // (array) $events
    );

    return $o;
  }
  
}