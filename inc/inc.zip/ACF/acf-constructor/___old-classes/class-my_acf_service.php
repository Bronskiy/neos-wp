<?php

class MY_ACF_SERVICES extends MY_ACF {

  public $acf_group_key = MY_CPT_SERVICE . '_acf_group_key';

  public $post_type = MY_CPT_SERVICE;

  public $active_acf_1; /* Контент */
  public $active_acf_2; /* Карточка услуги в архиве */
  public $active_acf_3; /* Форма */

  public $location;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'services_';

  public function register() {
    $this->acf = (object) [];

    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => $this->post_type,
        ],
      ),
    ];

    /* Контент */
    $this->active_acf_1 = [ 
      $this->acf_page_title( $this->id('aa1_', 20) ),
      // $this->acf_class_style_text([
      //   'id' => 30,
      //   'name' => 'page_subtitle',
      //   'label' => 'Подзаголовок',
      // ]),
      $this->acf_page_subtitle([
        'id' => $this->id('aa1_', 30),
        'label' => 'Подзаголовок',
      ]),

      $this->acf_hero_section_img([
        "id" => $this->id('aa1_', 40),
        "name" => "main_img",
      ]),

      $this->acf_group([
        "id" => $this->id('aa1_', 100),
        "name" => "gallery",
        "label" => "<h1>Галерея работ</h1>",
        "sub_fields" => [
          $this->acf_checkbox([
            'id' =>  $this->id('aa1_', 100, 10),
            'name' => 'options',
            'label' => 'Опции',
            'choices' => [
              'hide_gallery' => $this->label('Не показывать галерею', 'hide_gallery'),
            ],
            'default_value' => [],
          ]),
          $this->acf_taxonomy_relation([
            'id' => $this->id('aa1_', 100, 20),
            'name' => 'related_portf_cats',
            'label' => 'Категории портфолио для отображения на странице',
            'taxonomy' => portfolio_cat_TAX,
            'instructions' => 'Их для начала нужно установить в разделе: Портфолио -> Категории работ',
          ]),
        ],
        "layout" => "row",
      ]),
    ];

    /* Карточка услуги в архиве */
    $this->active_acf_2 = [
      $this->acf_archive_card([
        'id' => $this->id('aa6', 10),
      ]),
      $this->acf_order([
        'id' => $this->id('aa6', 5),
      ]),
    ];

    /* Форма */
    $this->active_acf_3 = [
      $this->acf_form_set([
        'id' => $this->id('aa3_', 10),
      ]),
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }






  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => 'Контент страницы',
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      
      $this->register_acf_group([
        'title' => 'Карточка услуги в архиве',
        'group_key' => $this->acf_group_key.'2',
        'fields' => $this->active_acf_2,
        'location' => $this->location,
      ]);

      $this->register_acf_group([
        'title' => 'Форма',
        'group_key' => $this->acf_group_key.'3',
        'fields' => $this->active_acf_3,
        'location' => $this->location,
      ]);
    };
  }



















  public function get_all_fields($post_id, $lang='') {
    if (__ACF_DEBUG__) echo " ___acf_service___ <br>\n";
    $o = (object) [];

    foreach ($this->active_acf_1 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    foreach ($this->active_acf_2 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    foreach ($this->active_acf_3 as $filed) {
      $acf_name = $filed['name'];
      $o->{$acf_name} = get_field($acf_name, $post_id);
    }
    return $o;
  }


}