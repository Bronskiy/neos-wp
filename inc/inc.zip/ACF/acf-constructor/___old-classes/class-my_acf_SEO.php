<?php

class MY_ACF_SEO extends MY_ACF {

  public $acf_group_key = 'my_seo_acf_group_key';

  public $active_acf;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = 'seo_';

  public function register() {
    $this->acf = (object) [];

    $this->active_acf = [
      $this->acf_text([
        'id'=>10,
        'name'=>'title',
        'label'=>'Title'
      ]),
      $this->acf_text([
        'id'=>20,
        'name'=>'keywords',
        'label'=>'Keywords (Ключевые слова)',
        'instructions'=>'Вводите слова без знаков препинания и все с маленькой буквы. Примерно 100 - 150 символов',
      ]),
      $this->acf_meta_tags(30),
    ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }







  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      acf_add_local_field_group([
        'key' => $this->acf_group_key,
        'title' => 'Дополнительная SEO настройка <b style="color:red">( обязательно! )</b>',
        'fields' => $this->active_acf,

        'location' => [
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => 'page',
            ],
            [
              'param' => 'page',
              'operator' => '!=',
              'value' => get_option('__about_us_post_id__'),
            ],
            [
              'param' => 'page',
              'operator' => '!=',
              'value' => get_option(__PRIVACY_POLICY_ID__),
            ],
          ),
          // array(
          //   [
          //     'param' => 'post_type',
          //     'operator' => '==',
          //     'value' => MY_CPT_TOURS,
          //   ],
          // ),
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => MY_CPT_SERVICE,
            ],
          ),
          array(
            [
              'param' => 'post_type',
              'operator' => '==',
              'value' => MY_CPT_PORTFOLIO,
            ],
          ),
          // array(
          //   [
          //     'param' => 'post_type',
          //     'operator' => '==',
          //     'value' => MY_CPT_EVENTS,
          //   ],
          // ),
        ],

        'menu_order' => 200 /* last one */,
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'active' => true,
      ]);
    };
  }







  private function acf_meta_tags( $id='' ) {
    $this->acf->meta_tags = 'meta_tags';
    $this->acf->meta_props = 'meta_props';
    return $this->acf_repeater([
      'id' => $id,
      'name' => $this->acf->meta_tags,
      'label' => 'Доп. мета данные к &lt;head&gt;...&lt;/head&gt;',
      'sub_fields' => [
        $this->acf_repeater([
          'id' => 'sub_' . $id,
          'name' => $this->acf->meta_props,
          'label' => 'meta-tags',
          'instructions' => '&lt;meta свойство="значение" свойство="значение" ...&gt;',
          'sub_fields' => [
            $this->acf_text([
              'id'=> '1_' . $id,
              'name'=> 'name',
              'label'=>'Property name',
            ]),
            $this->acf_text([
              'id'=> '2_' . $id,
              'name'=> 'value',
              'label'=>'Property Value',
            ]),
          ],
        ]),
      ],
    ]);
  }






  public function get_all_fields($post_id) {
    if (__ACF_DEBUG__) echo " ___acf_seo___ <br>\n";
    
    return $this->get_all_simple_fields([
      'post_id' => $post_id,
      'post_id_is_required' => 1,
    ]);
  }
  
}