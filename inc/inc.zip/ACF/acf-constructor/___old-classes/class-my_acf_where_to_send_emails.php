<?php

class MY_ACF_WHERE_TO_SEND_EMAILS extends MY_ACF {

  public $acf_group_key = '_where_to_send_emails_' . '_acf_group_key';

  public $post_type = '_where_to_send_emails_';

  public $active_acf_1; /* Все письма */
  // public $active_acf_2; /* Карточка услуги в архиве */
  // public $active_acf_3; /* Форма */

  public $location;

  public $acf;

  /* prefix must be unique among other ACF Class keys */
  /* use in uniqueKey() */
  public $uniqueIdPrefix = '__wtsm_';

  public function register() {
    $this->acf = (object) [];

    $this->location = [
      array(
        [
          'param' => 'post_type',
          'operator' => '==',
          'value' => MY_CPT_SETTINGS,
        ],
        [
          'param' => 'page',
          'operator' => '==',
          'value' => get_option('__where_send_emails_post_id__'),
        ],
      ),
    ];

    /* Все письма */
    $this->active_acf_1 = [
      $this->acf_group([
        'id' => $this->id('aa1', 10),
        'name' => 'all_emails',
        'label' => ' ',
        'layout' => 'block',
        'sub_fields' => [
          $this->acf_text([
            'id' => $this->id(['aa1', 10, 10]),
            'name' => 'dev_emails',
            'label' => 'Email разработчика',
            'instructions' => 'Используется ТОЛЬКО при разработке',
          ]),
          $this->acf_textarea([
            'id' => $this->id(['aa1', 10, 20]),
            'name' => 'emails',
            'label' => 'E-mails',
            'new_lines' => '',
            'instructions' => 'Напишите e-mail`ы через пробел или "enter"',
            'rows' => 6,
          ]),
        ],
      ])
    ];



    // /* Карточка услуги в архиве */
    // $this->active_acf_2 = [
    //   $this->acf_archive_card([
    //     'id' => $this->id('aa6', 10),
    //   ]),
    //   $this->acf_order([
    //     'id' => $this->id('aa6', 5),
    //   ]),
    // ];

    // /* Форма */
    // $this->active_acf_3 = [
    //   $this->acf_form_set([
    //     'id' => $this->id('aa3_', 10),
    //   ]),
    // ];

    add_action( 'acf/init', [$this, 'acf_init'] );
  }






  public function acf_init() {
    if( function_exists('acf_add_local_field_group') ) {
      $this->register_acf_group([
        'title' => 'Все письма',
        'group_key' => $this->acf_group_key,
        'fields' => $this->active_acf_1,
        'location' => $this->location,
      ]);
      
      // $this->register_acf_group([
      //   'title' => 'Карточка услуги в архиве',
      //   'group_key' => $this->acf_group_key.'2',
      //   'fields' => $this->active_acf_2,
      //   'location' => $this->location,
      // ]);

      // $this->register_acf_group([
      //   'title' => 'Форма',
      //   'group_key' => $this->acf_group_key.'3',
      //   'fields' => $this->active_acf_3,
      //   'location' => $this->location,
      // ]);
    };
  }



















  public function get_all_fields($post_id, $lang='') {
    if (__ACF_DEBUG__) echo " ___acf_where_to_send_emails___ <br>\n";
    $o = (object) [];

    foreach ($this->active_acf_1 as $filed) {
      $acf_name = $filed['name'];

      /* turn emails string into array */
      if ($acf_name = 'all_emails') {
        $x = get_field($acf_name, $post_id);
        foreach (get_field($acf_name, $post_id) as $key => $emails) {

          // $x[$key] = array_filter(explode(' ', $emails), function($e){
          $x[$key] = array_filter(explode(' ', u_str__new_line_and_multispaces_to_1_space($emails) ), function($e){
            if ($e) return 1;
          });
        }
        $o->{$acf_name} = $x;
      }
      else $o->{$acf_name} = get_field($acf_name, $post_id);
    }


    // foreach ($this->active_acf_2 as $filed) {
    //   $acf_name = $filed['name'];
    //   $o->{$acf_name} = get_field($acf_name, $post_id);
    // }
    // foreach ($this->active_acf_3 as $filed) {
    //   $acf_name = $filed['name'];
    //   $o->{$acf_name} = get_field($acf_name, $post_id);
    // }
    return $o;
  }


}



