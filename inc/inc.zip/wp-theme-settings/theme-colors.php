<?php

$GLOBALS["_COLORS_"] = [
  'primary' => '#f15a29',
  'gray_1' => '#f9f9f9',
];