<?php

define( '__GB_SHOW_ERRORS__', true );

require 'print_gb_content.php';
require 'print_gb_img.php';
require 'print_gb_gallery.php';
require 'print_gb_list.php';
require 'print_gb_youtube.php';