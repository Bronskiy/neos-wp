<?php

/***
  /wp-json/myrest/v1/test
***/
function REST__test() {
  echo "<pre class='r'>";
  print_r($_GET);
  echo "</pre>";



  echo "\n\n\n\n";
}